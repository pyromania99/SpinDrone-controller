"""Static checker for the thesis (no TeX toolchain available locally).

Usage:  python tools/check_thesis.py [--only <path-substring>]
Walks main.tex -> \\input / \\include / \\versioninput, and reports:
  ERROR  missing input/graphics, duplicate labels, undefined refs, unknown cite
         keys, unknown \\gls keys, spaces in file names, unbalanced braces/envs
  WARN   label naming scheme, figures without \\figsource, orphan figure files,
         cites only found in refs_staging.bib, files > 5 MB
  INFO   \\todo counts per file
"""
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]  # the thesis folder (tools/ lives inside it)
ONLY = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else None
def _enabled_versions():
    """Read \\vzerotrue / \\vonetrue ... from config/versions.tex."""
    txt = (ROOT / "config" / "versions.tex").read_text(encoding="utf-8")
    names = {"zero": "v0", "one": "v1", "two": "v2"}
    found = {names[m] for m in re.findall(r"^[^%\n]*\\v(zero|one|two)true", txt, re.M)}
    return found or {"v0"}
ENABLED_VERSIONS = _enabled_versions()  # mirrors config/versions.tex
GFX_EXT = [".pdf", ".png", ".jpg", ".jpeg"]
CHAP_KEYS = "intro|bg|model|ctrl|aero|plat|sim|exp|conc|app"
LABEL_RE = re.compile(rf"^(ch|app):[a-z0-9-]+$|^(fig|tab|eq|sec|subsec|alg|thm|lem|def|prop|rem|cor|asm|ex):({CHAP_KEYS})-v\d+:[a-z0-9-]+$")

errors, warns, infos = [], [], []
labels = defaultdict(list)      # label -> [file]
refs = []                       # (label, file)
cites = []                      # (key, file)
glss = []                       # (key, file)
used_gfx = set()
todo_count = Counter()
visited = []


def strip_comments(text):
    out = []
    for line in text.splitlines():
        m = re.search(r"(?<!\\)%", line)
        out.append(line[: m.start()] if m else line)
    return "\n".join(out)


def rel(p):
    try:
        return str(Path(p).resolve().relative_to(ROOT.resolve())).replace("\\", "/")
    except ValueError:
        return str(p)


def resolve_tex(name):
    p = ROOT / name
    if p.suffix != ".tex":
        p = p.with_suffix(p.suffix + ".tex") if p.suffix else p.with_suffix(".tex")
    return p


TOKEN = re.compile(
    r"\\(input|include|versioninput|includegraphics|renewcommand|label|ref|eqref|autoref|pageref|cref|Cref|cite|gls|glspl|Gls|Glspl|glsxtrshort|acrshort|acrlong|todo|todoverify|todoconflict|todofig|todocite|todowrite|placeholderfig|figsource|begin|end)\b"
)


def read_arg(text, i):
    """Read optional [..] args then one {...} group starting at i. Returns (arg, new_i)."""
    n = len(text)
    while i < n and text[i] in " \t\n*":
        i += 1
    while i < n and text[i] == "[":
        depth = 0
        while i < n:
            depth += text[i] == "["
            depth -= text[i] == "]"
            i += 1
            if depth == 0:
                break
        while i < n and text[i] in " \t\n":
            i += 1
    if i >= n or text[i] != "{":
        return None, i
    depth, j = 0, i
    while j < n:
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[i + 1 : j], j + 1
        j += 1
    return None, i


state = {"figdir": "."}


def walk(path, chain=()):
    path = Path(path)
    if not path.exists():
        errors.append(f"missing input: {rel(path)} (from {chain[-1] if chain else 'root'})")
        return
    r = rel(path)
    visited.append(r)
    raw = path.read_text(encoding="utf-8", errors="replace")
    text = strip_comments(raw)
    # same-length copy with \\ , \{ , \} , \% masked -> safe for brace matching
    clean = re.sub(r"\\\\", "  ", text)
    clean = re.sub(r"\\[{}%]", "  ", clean)
    # brace / environment balance
    opens = clean.count("{")
    closes = clean.count("}")
    if opens != closes:
        errors.append(f"unbalanced braces in {r}: {opens} '{{' vs {closes} '}}'")
    envs = Counter()
    fig_stack = []
    is_config = r.startswith("config/")
    for m in TOKEN.finditer(clean):
        cmd = m.group(1)
        arg, _ = read_arg(clean, m.end())
        if arg is not None:
            arg = text[_ - 1 - len(arg) : _ - 1]
        if is_config and cmd not in ("renewcommand",):
            continue
        if cmd.startswith("todo"):
            todo_count[r] += 1
            continue
        if arg is None:
            if cmd not in ("begin", "end", "figsource"):
                pass
            continue
        if cmd in ("input", "include"):
            walk(resolve_tex(arg), chain + (r,))
        elif cmd == "versioninput":
            ver, _ = read_arg(clean, _)
            # \versioninput uses \IfFileExists: a missing <dir>/<ver>/main.tex is skipped, not an error
            if ver in ENABLED_VERSIONS and (ROOT / arg / ver / "main.tex").exists():
                walk(ROOT / arg / ver / "main.tex", chain + (r,))
        elif cmd == "renewcommand":
            if arg.strip() == r"\figdir":
                val, _ = read_arg(clean, _)
                state["figdir"] = val
        elif cmd == "includegraphics":
            g = arg.replace(r"\figdir", state["figdir"])
            gp = ROOT / g
            found = gp if gp.suffix.lower() in GFX_EXT and gp.exists() else None
            if not found:
                for e in GFX_EXT:
                    if (ROOT / (g + e)).exists():
                        found = ROOT / (g + e)
                        break
            if not found:
                errors.append(f"missing graphics: {g} (in {r})")
            else:
                used_gfx.add(found.resolve())
            if fig_stack:
                fig_stack[-1]["gfx"] = True
        elif cmd == "figsource":
            if fig_stack:
                fig_stack[-1]["src"] = True
        elif cmd == "label":
            labels[arg].append(r)
            if not LABEL_RE.match(arg):
                warns.append(f"label scheme: '{arg}' in {r}")
        elif cmd in ("ref", "eqref", "autoref", "pageref", "cref", "Cref"):
            for k in arg.split(","):
                refs.append((k.strip(), r))
        elif cmd == "cite":
            for k in arg.split(","):
                if k.strip():
                    cites.append((k.strip(), r))
        elif cmd in ("gls", "glspl", "Gls", "Glspl", "glsxtrshort", "acrshort", "acrlong"):
            glss.append((arg.strip(), r))
        elif cmd == "begin":
            envs[arg] += 1
            if arg in ("figure", "figure*"):
                fig_stack.append({"gfx": False, "src": False, "pos": m.start()})
        elif cmd == "end":
            envs[arg] -= 1
            if arg in ("figure", "figure*") and fig_stack:
                f = fig_stack.pop()
                if f["gfx"] and not f["src"]:
                    line = text[: f["pos"]].count("\n") + 1
                    warns.append(f"figure without \\figsource: {r}:{line}")
    for env, c in envs.items():
        if c != 0:
            errors.append(f"unbalanced environment '{env}' in {r} (net {c:+d})")


walk(ROOT / "main.tex")

# ---- bibliography
bib_keys, staging_keys = Counter(), set()
for b in list((ROOT / "bib").glob("*.bib")):
    for k in re.findall(r"^\s*@\w+\s*\{\s*([^,\s]+)\s*,", b.read_text(encoding="utf-8"), re.M):
        bib_keys[k] += 1
for b in ROOT.rglob("refs_staging*.bib"):
    for k in re.findall(r"^\s*@\w+\s*\{\s*([^,\s]+)\s*,", b.read_text(encoding="utf-8"), re.M):
        staging_keys.add(k)
for k, c in bib_keys.items():
    if c > 1:
        errors.append(f"duplicate bib key across bib/*.bib: {k} (x{c})")
for k, f in cites:
    if k not in bib_keys:
        if k in staging_keys:
            warns.append(f"cite '{k}' only in refs_staging.bib ({f}) -- merge at integration")
        else:
            errors.append(f"unknown cite key '{k}' in {f}")

# ---- glossary
gls_keys = set()
for g in (ROOT / "glossary").glob("*.tex"):
    t = g.read_text(encoding="utf-8")
    gls_keys |= set(re.findall(r"\\newacronym(?:\[[^\]]*\])?\{([^}]+)\}", t))
    gls_keys |= set(re.findall(r"\\glsxtrnewsymbol(?:\[[^\]]*\])?\{([^}]+)\}", t))
for k, f in glss:
    if k not in gls_keys:
        errors.append(f"unknown glossary key '{k}' in {f}")

# ---- labels / refs
for lab, files in labels.items():
    if len(files) > 1:
        errors.append(f"duplicate label '{lab}' in {sorted(set(files))}")
for lab, f in refs:
    if lab not in labels:
        errors.append(f"undefined ref '{lab}' in {f}")

# ---- files
for p in ROOT.rglob("*"):
    if "_template_samples" in p.parts or not p.is_file():
        continue
    if " " in p.name:
        errors.append(f"space in file name: {rel(p)}")
    if p.stat().st_size > 5 * 1024 * 1024:
        warns.append(f"large file (>5 MB): {rel(p)} ({p.stat().st_size/1e6:.1f} MB)")
    if p.suffix.lower() in GFX_EXT and "figures" in p.parts and p.resolve() not in used_gfx:
        if "common" not in p.parts:
            warns.append(f"orphan figure (not included): {rel(p)}")
    if p.suffix.lower() in GFX_EXT and p.name.count(".") > 1:
        errors.append(f"extra dots in graphics file name (breaks graphicx): {rel(p)}")


def show(tag, items):
    items = [i for i in items if ONLY is None or ONLY in i]
    for i in items:
        print(f"{tag:5} {i}")
    return len(items)


ne = show("ERROR", errors)
nw = show("WARN", warns)
print("----- todo notes per file")
for f, c in sorted(todo_count.items()):
    if ONLY is None or ONLY in f:
        print(f"INFO  {c:3d}  {f}")
print(f"----- {len(visited)} tex files walked, {len(labels)} labels, {len(set(k for k,_ in cites))} cite keys, "
      f"{len(used_gfx)} graphics; {ne} errors, {nw} warnings (filter: {ONLY})")
sys.exit(1 if ne else 0)
