"""Case-exact path check for Linux builds.

Windows file systems are case-insensitive, so tools/check_thesis.py cannot catch an
\\input or \\includegraphics whose case differs from the file on disk. This script
compares every referenced path component against the real directory listing.
Usage: python tools/check_case.py
"""
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GFX_EXT = [".pdf", ".png", ".jpg", ".jpeg"]


def exact(rel):
    """True if rel (posix, relative to ROOT) exists with exactly this case."""
    cur = ROOT
    for part in rel.split("/"):
        if part in ("", "."):
            continue
        try:
            names = os.listdir(cur)
        except NotADirectoryError:
            return False
        if part not in names:
            return False
        cur = cur / part
    return True


problems, n = [], 0
for p in sorted(ROOT.rglob("*.tex")):
    if "_template_samples" in p.parts:
        continue
    t = "\n".join(re.sub(r"(?<!\\)%.*", "", l) for l in p.read_text(encoding="utf-8").splitlines())
    m = re.search(r"\\renewcommand\{\\figdir\}\{([^}]*)\}", t)
    figdir = m.group(1) if m else p.parent.relative_to(ROOT).as_posix() + "/figures"
    for m in re.finditer(r"\\(input|include)\{([^}#]+)\}", t):
        n += 1
        f = m.group(2) if m.group(2).endswith(".tex") else m.group(2) + ".tex"
        if not exact(f):
            problems.append(f"{p.relative_to(ROOT)}: \\{m.group(1)}{{{m.group(2)}}}")
    for m in re.finditer(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", t):
        n += 1
        g = m.group(1).replace("\\figdir", figdir)
        ok = exact(g) if Path(g).suffix.lower() in GFX_EXT else any(exact(g + e) for e in GFX_EXT)
        if not ok:
            problems.append(f"{p.relative_to(ROOT)}: \\includegraphics{{{m.group(1)}}} -> {g}")
for f in ["iiit_thesis.sty", "IEEEtran.cls", "glossary/acronyms.tex", "glossary/symbols.tex",
          "bib/core.bib", "bib/v0.bib", "bib/v1.bib", "figures/common/iiit.png"]:
    n += 1
    if not exact(f):
        problems.append(f"support file: {f}")
print("\n".join(problems) or "all paths match case exactly")
print(f"{n} references checked, {len(problems)} problems")
