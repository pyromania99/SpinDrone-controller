#!/usr/bin/env python3
"""Time histories of the v1 hardware eigen flights (thesis Chapter 8, v1).

Reads the flight logs in place (no simulator) and writes two PNGs:
  exp_log1_history.png  -- 30th_2tilt/log_1: spin rate, tilt error, motor commands, height
  exp_log6_height.png   -- eigen/log_6: raw barometric height vs the EKF (EV-referenced) height

Tilt error = angle between the body z axis of vehicle_attitude and that of
vehicle_attitude_setpoint (interpolated onto the attitude time base).

    python3 plot_hw_flights.py [--logs ~/Downloads/logs] [--out <dir>]
"""
import argparse, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pyulog import ULog

INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
S1, S2, S3, S4 = "#2a78d6", "#eb6834", "#1baf7a", "#4a3aa7"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True,
                     "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
                     "axes.spines.right": False, "lines.linewidth": 1.0})


def zaxis(q):
    w, x, y, z = q.T
    return np.stack([2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)], 1)


def load(path, topics):
    u = ULog(path, topics)
    return {d.name: d.data for d in u.data_list}


def airborne(d):
    ld = d["vehicle_land_detected"]
    t = ld["timestamp"][ld["landed"] == 0] / 1e6
    return t[0], t[-1]


def log1(path, out):
    d = load(path, ["vehicle_attitude", "vehicle_attitude_setpoint", "vehicle_angular_velocity",
                    "actuator_motors", "vehicle_local_position", "vehicle_land_detected"])
    a0, a1 = airborne(d)
    av = d["vehicle_angular_velocity"]; tw = av["timestamp"] / 1e6
    at = d["vehicle_attitude"]; ta = at["timestamp"] / 1e6
    q = np.stack([at[f"q[{i}]"] for i in range(4)], 1)
    sp = d["vehicle_attitude_setpoint"]; ts = sp["timestamp"] / 1e6
    qd = np.stack([np.interp(ta, ts, sp[f"q_d[{i}]"]) for i in range(4)], 1)
    qd /= np.linalg.norm(qd, axis=1, keepdims=True)
    err = np.degrees(np.arccos(np.clip(np.sum(zaxis(q) * zaxis(qd), 1), -1, 1)))
    mo = d["actuator_motors"]; tm = mo["timestamp"] / 1e6
    lp = d["vehicle_local_position"]; tl = lp["timestamp"] / 1e6
    t0 = a0
    fig, ax = plt.subplots(4, 1, figsize=(6.4, 7.0), sharex=True)
    ax[0].plot(tw - t0, av["xyz[2]"], color=S1)
    ax[0].set_ylabel("yaw rate [rad/s]")
    k = np.ones(40) / 40
    ax[1].plot(ta - t0, err, color=GRID, lw=0.6, label="instantaneous")
    ax[1].plot(ta - t0, np.sqrt(np.convolve(err ** 2, k, "same")), color=S1, label="0.2 s rms")
    ax[1].set_ylabel("tilt error [deg]"); ax[1].legend(loc="upper left", frameon=False, ncol=2)
    for i, c in enumerate([S1, S2, S3, S4]):
        ax[2].plot(tm - t0, mo[f"control[{i}]"], color=c, lw=0.6, label=f"motor {i}")
    ax[2].set_ylabel("motor command [-]"); ax[2].legend(loc="upper left", frameon=False, ncol=4)
    ax[3].plot(tl - t0, -lp["z"], color=S1)
    ax[3].set_ylabel("height (EKF) [m]"); ax[3].set_xlabel("time since lift-off [s]")
    for a in ax:
        a.axvspan(0, a1 - a0, color="#f0efec", zorder=0)
    ax[3].set_xlim(-5, a1 - a0 + 5)
    fig.tight_layout(); fig.savefig(os.path.join(out, "exp_log1_history.png"), dpi=200)
    m = (ta > a0 + 5) & (ta < a1 - 5)
    mw = (tw > a0 + 5) & (tw < a1 - 5)
    print(f"log_1 airborne {a1-a0:.1f} s; r median {np.median(av['xyz[2]'][mw]):.2f}; tilt err rms {np.sqrt(np.mean(err[m]**2)):.2f} deg, max {err[m].max():.1f}")


def log6(path, out):
    d = load(path, ["vehicle_air_data", "vehicle_local_position", "vehicle_land_detected"])
    a0, a1 = airborne(d)
    ad = d["vehicle_air_data"]; tb = ad["timestamp"] / 1e6
    lp = d["vehicle_local_position"]; tl = lp["timestamp"] / 1e6
    h = -lp["z"]; b = ad["baro_alt_meter"]
    pre = tb < a0 - 2
    b = b - np.median(b[pre][:20])
    h = h - np.median(h[tl < a0 - 2][:100])
    fig, ax = plt.subplots(1, 1, figsize=(6.4, 3.0))
    ax.axvspan(0, a1 - a0, color="#f0efec", zorder=0)
    ax.plot(tb - a0, b, color=S2, label="raw barometric height")
    ax.plot(tl - a0, h, color=S1, label="EKF height (EV reference)")
    ax.set_xlabel("time since lift-off [s]"); ax.set_ylabel("height change [m]")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(out, "exp_log6_height.png"), dpi=200)
    print(f"log_6 airborne {a1-a0:.1f} s; baro end-of-log offset {b[-20:].mean():.2f} m; EKF height airborne median {np.median(h[(tl>a0)&(tl<a1)]):.2f}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--logs", default=os.path.expanduser("~/Downloads/logs"))
    p.add_argument("--out", default=".")
    a = p.parse_args()
    log1(os.path.join(a.logs, "30th_2tilt/log_1_2026-9-30-21-50-08.ulg"), a.out)
    log6(os.path.join(a.logs, "eigen/log_6_eigen_spin.ulg"), a.out)
