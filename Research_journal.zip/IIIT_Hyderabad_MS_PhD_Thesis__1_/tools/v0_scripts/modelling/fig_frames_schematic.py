"""Schematic of the body frame, rotor numbering and tangential cant (thesis Ch. 3, v0).

Pure geometry, no data. Conventions follow chapters/03_modelling/v0/rotor_model.tex:
  NED body frame, x_B forward, y_B right, z_B down (into the page in the top view).
  Rotor i sits at r_i = l [cos b_i, sin b_i, 0] with b = 225, 315, 135, 45 deg for
  i = 1..4 (1 rear-left, 2 front-left, 3 rear-right, 4 front-right).
  Tangential unit vector t_i = [-sin b_i, cos b_i, 0]; thrust axis u_i = sin(a) t_i - cos(a) z_B.
Output: <thesis>/chapters/03_modelling/v0/figures/frames_cant_schematic.pdf
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, Arc, Polygon, Rectangle

OUT = (r"C:/Users/anike/Desktop/RESEARCH/spin_drone/IIIT_Hyderabad_MS_PhD_Thesis__1_"
       r"/chapters/03_modelling/v0/figures/frames_cant_schematic.pdf")

INK = "#0b0b0b"
MUTED = "#52514e"
GRID = "#d6d5d0"
BLUE = "#2a78d6"     # thrust / force quantities
ORANGE = "#eb6834"   # tangential quantities
WING = "#e9e7e1"

plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm", "font.family": "serif"})


def arrow(ax, p0, p1, color=INK, lw=1.3, ms=9, ls="-", z=3):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=ms,
                                 color=color, lw=lw, linestyle=ls, zorder=z,
                                 shrinkA=0, shrinkB=0))


def body_to_page(xb, yb):
    """Top view seen from above: page X = y_B (right), page Y = x_B (up)."""
    return np.array([yb, xb])


fig, (ax, bx) = plt.subplots(1, 2, figsize=(6.3, 3.3), gridspec_kw={"width_ratios": [1.25, 1.0]})

# ------------------------------------------------------------------ (a) top view
beta = np.radians([225.0, 315.0, 135.0, 45.0])
names = ["1", "2", "3", "4"]
R = 1.0                     # motor radius (normalised l)
r_in, r_out = 1.35, 2.15    # indicative wing radii (not to scale)

for i, b in enumerate(beta):
    rhat = np.array([np.cos(b), np.sin(b)])
    that = np.array([-np.sin(b), np.cos(b)])
    # wing outline along the arm, outboard of the motor (indicative only)
    c = 0.32
    pts = []
    for rr, side in ((r_in, -1), (r_out, -1), (r_out, 1), (r_in, 1)):
        xb, yb = rr * rhat + side * c / 2 * that
        pts.append(body_to_page(xb, yb))
    ax.add_patch(Polygon(pts, closed=True, fc=WING, ec=GRID, lw=0.8, zorder=1))
    # arm
    p_m = body_to_page(*(R * rhat))
    ax.plot([0, p_m[0]], [0, p_m[1]], color=MUTED, lw=2.2, solid_capstyle="round", zorder=2)
    ax.add_patch(Circle(p_m, 0.13, fc="white", ec=INK, lw=1.0, zorder=4))
    ax.text(*p_m, names[i], ha="center", va="center", fontsize=8, zorder=5)
    # tangential unit vector at the motor
    p_t = body_to_page(*(R * rhat + 0.55 * that))
    arrow(ax, p_m + 0.13 * (p_t - p_m) / np.linalg.norm(p_t - p_m), p_t, color=ORANGE, lw=1.4)

# label one tangential vector and one position vector
b4 = beta[3]
p4 = body_to_page(*(R * np.array([np.cos(b4), np.sin(b4)])))
t4 = body_to_page(*(R * np.array([np.cos(b4), np.sin(b4)]) + 0.55 * np.array([-np.sin(b4), np.cos(b4)])))
ax.text(t4[0] + 0.05, t4[1] - 0.12, r"$\hat{\mathbf{t}}_4$", color=INK, fontsize=10)
ax.text(0.33, 0.12, r"$\mathbf{r}_4$", fontsize=10, color=INK)
ax.text(0.45, -2.42, r"all arms: $\Vert\mathbf{r}_i\Vert=l$", fontsize=7.5, color=MUTED)
# arm angle beta_4 measured from x_B towards y_B
ax.add_patch(Arc((0, 0), 0.9, 0.9, theta1=45, theta2=90, color=MUTED, lw=0.9))
ax.text(0.17, 0.52, r"$\beta_4$", fontsize=8, color=MUTED)

# body axes: x_B up (forward), y_B right; z_B into the page (down, NED)
arrow(ax, (0, 0), (0, 1.75), color=INK, lw=1.2)
arrow(ax, (0, 0), (1.75, 0), color=INK, lw=1.2)
ax.text(0.06, 1.72, r"$x_{\mathcal{B}}$ (forward)", fontsize=9)
ax.text(1.62, -0.22, r"$y_{\mathcal{B}}$", fontsize=9)
ax.add_patch(Circle((0, 0), 0.10, fc="white", ec=INK, lw=1.0, zorder=6))
ax.plot([-0.07, 0.07], [-0.07, 0.07], color=INK, lw=0.9, zorder=7)
ax.plot([-0.07, 0.07], [0.07, -0.07], color=INK, lw=0.9, zorder=7)
ax.text(-1.15, 0.10, r"$z_{\mathcal{B}}$ (down)", fontsize=9)

# spin arrow: clockwise seen from above = positive rotation about +z_B (down)
th = np.linspace(np.radians(160), np.radians(110), 40)
rr = 2.35
ax.plot(rr * np.cos(th), rr * np.sin(th), color=BLUE, lw=1.4)
arrow(ax, (rr * np.cos(th[-2]), rr * np.sin(th[-2])), (rr * np.cos(th[-1]) + 0.02, rr * np.sin(th[-1]) + 0.02),
      color=BLUE, lw=1.4)
ax.text(-2.35, 2.05, r"$\omega_z>0$", color=INK, fontsize=9)
ax.text(-2.2, -2.42, "wing (indicative)", fontsize=7.5, color=MUTED)

ax.set_xlim(-2.5, 2.5)
ax.set_ylim(-2.5, 2.5)
ax.set_aspect("equal")
ax.axis("off")
ax.set_title("(a) top view, body frame", fontsize=9, loc="left")

# ------------------------------------------------------------------ (b) cant, side view
# viewed from outside the rotor, looking radially inwards: horizontal = t_i, vertical = -z_B (up)
a = np.radians(25.0)        # cant drawn exaggerated for legibility
u = np.array([np.sin(a), np.cos(a)])           # thrust axis in (t, up) coordinates
perp = np.array([np.cos(a), -np.sin(a)])
hub = np.array([0.0, 0.0])
# arm cross-section and motor
bx.add_patch(Rectangle((-0.12, -0.42), 0.24, 0.24, fc=MUTED, ec=INK, lw=0.8))
mot = Polygon([hub - 0.16 * perp - 0.18 * u, hub + 0.16 * perp - 0.18 * u,
               hub + 0.16 * perp + 0.05 * u, hub - 0.16 * perp + 0.05 * u],
              closed=True, fc="#bdbcb6", ec=INK, lw=0.8)
bx.add_patch(mot)
bx.plot([-0.12, 0.12], [-0.18, -0.18], color=INK, lw=0.8)
# propeller disc (edge-on), perpendicular to u
pc = hub + 0.12 * u
bx.plot(*(np.c_[pc - 0.75 * perp, pc + 0.75 * perp]), color=INK, lw=2.0, solid_capstyle="round")
# thrust vector and its components
F = 1.55
tip = pc + F * u
arrow(bx, pc, tip, color=BLUE, lw=1.8, ms=11)
bx.text(tip[0] + 0.06, tip[1] + 0.02, r"$\mathbf{F}_i=f_i\,\hat{\mathbf{u}}_i$", fontsize=10)
vert = pc + np.array([0.0, F * np.cos(a)])
horz = pc + np.array([F * np.sin(a), 0.0])
arrow(bx, pc, vert, color=BLUE, lw=1.1, ls=(0, (3, 2)))
arrow(bx, pc, horz, color=ORANGE, lw=1.4)
bx.plot([vert[0], tip[0]], [vert[1], tip[1]], color=GRID, lw=0.8)
bx.plot([horz[0], tip[0]], [horz[1], tip[1]], color=GRID, lw=0.8)
bx.text(vert[0] - 0.95, vert[1] - 0.25, r"$f_i\cos\alpha$", fontsize=9)
bx.text(horz[0] + 0.10, horz[1] + 0.06, r"$f_i\sin\alpha$", fontsize=9)
bx.add_patch(Arc(pc, 1.3, 1.3, theta1=90 - np.degrees(a), theta2=90, color=INK, lw=0.9))
bx.text(pc[0] + 0.12, pc[1] + 0.72, r"$\alpha$", fontsize=10)
# reference axes
arrow(bx, (-1.25, -0.75), (-1.25, 0.05), color=INK, lw=1.0)
arrow(bx, (-1.25, -0.75), (-0.45, -0.75), color=ORANGE, lw=1.0)
bx.text(-1.5, 0.12, r"$-z_{\mathcal{B}}$ (up)", fontsize=9)
bx.text(-0.5, -0.98, r"$\hat{\mathbf{t}}_i$", fontsize=10)
bx.text(-1.4, -1.3, "arm points out of the page", fontsize=7.5, color=MUTED)
bx.set_xlim(-1.6, 1.9)
bx.set_ylim(-1.4, 2.0)
bx.set_aspect("equal")
bx.axis("off")
bx.set_title(r"(b) tangential cant of rotor $i$", fontsize=9, loc="left")

fig.tight_layout(w_pad=0.5)
fig.savefig(OUT, bbox_inches="tight")
fig.savefig(__file__.replace(".py", "_preview.png"), dpi=150, bbox_inches="tight")  # scratch preview only
print("saved", OUT)
