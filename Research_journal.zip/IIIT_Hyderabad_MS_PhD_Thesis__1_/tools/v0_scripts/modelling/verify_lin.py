import numpy as np
w,g,m,Jx,Jy,Jz,Hr,KL,KD,al,l,kap=9.27,9.81,0.8,0.008,0.009,0.012,0.0003,0.06,0.012,np.radians(10),0.3,0.015
kx=((Jz-Jy)*w-Hr)/Jx; ky=((Jz-Jx)*w-Hr)/Jy; aL=2*KL*w/m; aD=2*KD*w/Jz
ps=0.7; A=np.zeros((12,12))
A[0,6],A[0,7],A[1,6],A[1,7]=np.cos(ps),-np.sin(ps),np.sin(ps),np.cos(ps)
A[2,8]=1;A[3,4]=w;A[3,9]=1;A[4,3]=-w;A[4,10]=1;A[5,11]=1
A[6,4]=-g;A[6,7]=w;A[7,3]=g;A[7,6]=-w;A[8,11]=-aL;A[9,10]=-kx;A[10,9]=ky;A[11,11]=-aD
ev=np.sort_complex(np.linalg.eigvals(A)); print(np.round(ev,4))
pred=[0]*5+[-aD]+[1j*w,-1j*w]*2+[1j*np.sqrt(kx*ky),-1j*np.sqrt(kx*ky)]
print(np.round(np.sort_complex(np.array(pred,dtype=complex)),4))
lxy=l*np.cos(al)-kap*np.sin(al); lz=l*np.sin(al)+kap*np.cos(al)
bF=np.sin(al)/(np.sqrt(2)*m);bw=np.cos(al)/m;bx=lxy/(np.sqrt(2)*Jx);by=lxy/(np.sqrt(2)*Jy);bz=lz/Jz
B=np.zeros((12,4));B[6]=bF*np.array([1,1,-1,-1]);B[7]=bF*np.array([-1,1,-1,1]);B[8]=-bw;B[9]=bx*np.array([1,1,-1,-1]);B[10]=by*np.array([-1,1,-1,1]);B[11]=bz
print('rank B',np.linalg.matrix_rank(B),'Bn',B@np.array([1,-1,-1,1]))
# check B against direct force/moment from geometry (NED, beta=225,315,135,45)
beta=np.radians([225,315,135,45]); F=np.zeros((3,4));M=np.zeros((3,4))
for i,b in enumerate(beta):
    r=l*np.array([np.cos(b),np.sin(b),0]); t=np.array([-np.sin(b),np.cos(b),0]); z=np.array([0,0,1.])
    u=np.sin(al)*t-np.cos(al)*z; F[:,i]=u; M[:,i]=np.cross(r,u)-kap*u
print('F/m vs B rows7-9', np.allclose(F/m,B[6:9]), ' M/J vs rows10-12', np.allclose(M/np.array([[Jx],[Jy],[Jz]]),B[9:12]))
