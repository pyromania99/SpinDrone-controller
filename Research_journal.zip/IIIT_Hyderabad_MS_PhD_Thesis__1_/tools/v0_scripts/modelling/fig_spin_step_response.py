"""Open-loop roll/pitch response of a spinning rigid body to a step moment (thesis Ch. 3, v0).

Analytical formulas (chapters/03_modelling/v0/stability.tex), cross-checked against a
nonlinear rigid-body simulation (Euler equations + rotation-matrix kinematics, RK4).

Parameters (illustrative, from workspace sources):
  J = Jxx = Jyy = 0.008 kg m^2, Jzz = 0.012 kg m^2 : 03_simulation/mujoco/models/quad_spinning.xml
  spin wbar = 9.27 rad/s                         : 07_paper/ICUAS/main.tex (MuJoCo steady spin)
  rotor angular momentum H_r = 0 (as in all v0 simulations)
Angles are normalised by M0/(J wbar^2), so the result does not depend on M0 (linear regime).

Cases
  (a,b) constant moment M0 about body x (fixed in the spinning body):
        - ICUAS draft model (phi_dot = w_x):  phi = M0/(J k^2)(1-cos kt),  theta = M0/(J k)(t - sin(kt)/k)
        - exact linearisation (phi_dot = w_x + wbar*theta, theta_dot = w_y - wbar*phi):
          eta = phi + j theta = (M0/J)[1/(k wbar) - e^{jkt}/(k(k+wbar)) - e^{-j wbar t}/(wbar(k+wbar))]
  (c)   constant moment M0 about the inertial x (north) axis, world-frame tilt:
          phi_w = M0/(J W^2)(1 - cos Wt),  theta_w = (M0/J)(t/W - sin(Wt)/W^2),  W = k + wbar = Jzz wbar / J
Output: <thesis>/chapters/03_modelling/v0/figures/spin_step_response.pdf
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = (r"C:/Users/anike/Desktop/RESEARCH/spin_drone/IIIT_Hyderabad_MS_PhD_Thesis__1_"
       r"/chapters/03_modelling/v0/figures/spin_step_response.pdf")

J, JZ = 0.008, 0.012
WBAR = 9.27
M0 = 1e-4
k = (JZ - J) / J * WBAR
W = k + WBAR
SCALE = M0 / (J * WBAR**2)          # normalisation of angles
T_END, DT = 2.0, 2e-4
t = np.arange(0.0, T_END + DT / 2, DT)

# ------------------------------------------------------------------ analytical
phi_draft = M0 / (J * k**2) * (1 - np.cos(k * t))
th_draft = M0 / (J * k) * (t - np.sin(k * t) / k)
eta = (M0 / J) * (1 / (k * WBAR) - np.exp(1j * k * t) / (k * (k + WBAR))
                  - np.exp(-1j * WBAR * t) / (WBAR * (k + WBAR)))
phi_ex, th_ex = eta.real, eta.imag
phiw_lin = M0 / (J * W**2) * (1 - np.cos(W * t))
thw_lin = (M0 / J) * (t / W - np.sin(W * t) / W**2)


# ------------------------------------------------------------------ nonlinear simulation
def hat(w):
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])


Jm = np.diag([J, J, JZ])
Jinv = np.linalg.inv(Jm)


def simulate(world_fixed):
    R = np.eye(3)
    w = np.array([0.0, 0.0, WBAR])
    out = np.zeros((t.size, 4))

    def f(R, w):
        Mb = R.T @ np.array([M0, 0, 0]) if world_fixed else np.array([M0, 0, 0])
        wdot = Jinv @ (Mb - np.cross(w, Jm @ w))
        Rdot = R @ hat(w)
        return Rdot, wdot

    for n in range(t.size):
        phi = np.arctan2(R[2, 1], R[2, 2])
        th = -np.arcsin(np.clip(R[2, 0], -1, 1))
        z_b = R[:, 2]
        out[n] = [phi, th, -z_b[1], z_b[0]]          # body-heading tilt, world tilt (phi_w, theta_w)
        k1R, k1w = f(R, w)
        k2R, k2w = f(R + DT / 2 * k1R, w + DT / 2 * k1w)
        k3R, k3w = f(R + DT / 2 * k2R, w + DT / 2 * k2w)
        k4R, k4w = f(R + DT * k3R, w + DT * k3w)
        R = R + DT / 6 * (k1R + 2 * k2R + 2 * k3R + k4R)
        w = w + DT / 6 * (k1w + 2 * k2w + 2 * k3w + k4w)
        u, _, vt = np.linalg.svd(R)
        R = u @ vt
    return out


nl_body = simulate(world_fixed=False)
nl_world = simulate(world_fixed=True)

err_b = max(np.max(np.abs(nl_body[:, 0] - phi_ex)), np.max(np.abs(nl_body[:, 1] - th_ex))) / SCALE
err_w = max(np.max(np.abs(nl_world[:, 2] - phiw_lin)), np.max(np.abs(nl_world[:, 3] - thw_lin))) / SCALE
print(f"k = {k:.3f} rad/s, W = {W:.3f} rad/s")
print(f"max |nonlinear - exact linear| (normalised): body-fixed {err_b:.2e}, world-fixed {err_w:.2e}")
print(f"normalised means: draft phi {1/(J*k**2)/(1/(J*WBAR**2)):.3f}, exact phi {WBAR/k:.3f}, "
      f"world phi_w {(WBAR/W)**2:.3f}")
print(f"normalised draft theta at t={T_END}s: {th_draft[-1]/SCALE:.2f}; exact theta max {np.max(np.abs(th_ex))/SCALE:.3f}")

# ------------------------------------------------------------------ plot
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3de"
plt.rcParams.update({"font.size": 8.5, "mathtext.fontset": "cm", "font.family": "serif",
                     "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED})

fig, axs = plt.subplots(1, 3, figsize=(6.4, 2.45), sharex=True)
mk = slice(0, None, 500)
panels = [
    (axs[0], phi_ex, phi_draft, nl_body[:, 0], r"$\phi\,/\,(M_0/J\bar\omega_z^2)$",
     "(a) body-fixed $M_0$: roll $\\phi$"),
    (axs[1], th_ex, th_draft, nl_body[:, 1], r"$\theta\,/\,(M_0/J\bar\omega_z^2)$",
     "(b) body-fixed $M_0$: pitch $\\theta$"),
]
for ax, ex, dr, nl, ylab, title in panels:
    ax.plot(t, dr / SCALE, color=ORANGE, lw=1.4, ls=(0, (4, 2)), label=r"ICUAS draft model ($\dot\phi\approx\omega_x$)")
    ax.plot(t, ex / SCALE, color=BLUE, lw=1.4, label="linearised, exact kinematics")
    ax.plot(t[mk], nl[mk] / SCALE, ls="none", marker="o", ms=2.3, mfc="white", mec=AQUA, mew=0.9,
            label="nonlinear simulation")
    ax.set_ylabel(ylab)
    ax.set_title(title, fontsize=8.5, loc="left")
axs[1].set_ylim(-3, 40)

ax = axs[2]
ax.plot(t, phiw_lin / SCALE, color=BLUE, lw=1.4)
ax.plot(t, thw_lin / SCALE, color=BLUE, lw=1.4, ls=(0, (1, 1.2)))
ax.plot(t[mk], nl_world[mk, 2] / SCALE, ls="none", marker="o", ms=2.3, mfc="white", mec=AQUA, mew=0.9)
ax.plot(t[mk], nl_world[mk, 3] / SCALE, ls="none", marker="o", ms=2.3, mfc="white", mec=AQUA, mew=0.9)
ax.text(0.12, 9.3, r"$\theta_{\mathrm{w}}$ (precession)", fontsize=8, color=INK)
ax.text(1.0, 2.0, r"$\phi_{\mathrm{w}}$ (nutation)", fontsize=8, color=INK)
ax.set_ylabel(r"world tilt $/\,(M_0/J\bar\omega_z^2)$")
ax.set_title("(c) world-fixed $M_0$", fontsize=8.5, loc="left")

for ax in axs:
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    ax.set_xlabel("time (s)")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(0.5, 1.04))
fig.tight_layout(rect=(0, 0, 1, 0.93), w_pad=0.6)
fig.savefig(OUT, bbox_inches="tight")
fig.savefig(__file__.replace(".py", "_preview.png"), dpi=160, bbox_inches="tight")
print("saved", OUT)
