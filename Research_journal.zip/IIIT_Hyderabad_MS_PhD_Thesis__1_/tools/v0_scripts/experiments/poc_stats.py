"""Agent D: Feb 2025 proof-of-concept statistics.
spin2 data: old_data/mavlink_data_spin2.xlsx (sheet mavlink_data_spin2) == POC_DATA/'ani 3.xlsx' source of spin_*.png
hover data: old_data/mavlink_data_run2.csv == source of hover_signals.png (ani.xlsx / ani.2.xlsx)."""
import os, numpy as np
from campaign2025_stats import load_csv, load_xlsx_sheet, spread, R
from spinphase import run
import datetime
for name, (att, srv) in {
    'spin2 (xlsx)': load_xlsx_sheet(os.path.join(R,'old_data','mavlink_data_spin2.xlsx'),'mavlink_data_spin2'),
    'run2 (csv)': load_csv(os.path.join(R,'old_data','mavlink_data_run2.csv')),
    'spin1 (csv)': load_csv(os.path.join(R,'old_data','mavlink_data_spin1.csv')),
    'rest (csv)': load_csv(os.path.join(R,'old_data','mavlink_data_rest.csv')),
}.items():
    print('==', name, 'start', datetime.datetime.fromtimestamp(att[0,0], datetime.UTC), 'n_att', len(att), 'n_srv', len(srv))
    run(name, att, srv)
    ta = spread(att[:,0]); yaw = np.unwrap(att[:,3]); ts = spread(srv[:,0]) if len(srv) else np.array([])
    t0 = ta[0]
    for b in np.arange(0, ta[-1]-t0, 4.0):
        m = (ta-t0>=b)&(ta-t0<b+4); ms = (ts-t0>=b)&(ts-t0<b+4) if len(ts) else np.zeros(0,bool)
        if m.sum()<4: continue
        r = np.polyfit(ta[m], yaw[m], 1)[0]
        c = np.round(srv[ms,1:5].mean(0)).astype(int) if ms.any() else None
        print(f"  t={b:4.0f} r={r:6.2f} roll={np.degrees(np.abs(att[m,1]).max()):5.1f} pitch={np.degrees(np.abs(att[m,2]).max()):5.1f} cmd={c}")
