"""Agent D: sensitivity of the inferred wing lift to the command-to-thrust model.
Mean stabilised commands from hover2026_stats.py (reproduces analyze_hover.py)."""
import numpy as np
s = dict(cw4=1809.0, sp4=1486.8, st2=1339.4, sp2=1132.7, st4=1588.1)
m4, m2, c = 960., 658., np.cos(np.radians(10))
def lift(T4, T2):  # 4-wing uses cos(10 deg) on all motors (as analyze_hover.py); 2-wing uses tilt 0 (as script)
    L4 = m4 - T4*c; L2 = m2 - T2
    return L4, L4/m4*100, L4/4, L2, L2/m2*100, L2/2
models = {}
p = np.polyfit([1050, s['st2'], s['cw4']], [450, m2, m4], 2); models['quadratic, 3 points (paper)'] = np.poly1d(p)
k = (m4 - m2)/(s['cw4'] - s['st2']); models['linear through the two hover points'] = lambda x: m2 + k*(x - s['st2'])
models['proportional, T = k s (per configuration)'] = None
models['square law, T = k s^2 (per configuration)'] = None
for name, f in models.items():
    if f is None:
        n = 1 if 'proportional' in name else 2
        T4 = m4*(s['sp4']/s['cw4'])**n; T2 = m2*(s['sp2']/s['st2'])**n
    else:
        T4, T2 = f(s['sp4']), f(s['sp2'])
    L = lift(T4, T2)
    print(f"{name:45s} T4={T4:6.1f} L4={L[0]:6.1f}g ({L[1]:4.1f}%) per-wing {L[2]:5.1f} | T2={T2:6.1f} L2={L[3]:6.1f}g ({L[4]:4.1f}%) per-wing {L[5]:5.1f}")
# config I: only two motors canted -> vertical factor (1+cos)/2 if equal split
f = models['quadratic, 3 points (paper)']; T2 = f(s['sp2'])
print('config I with two of four motors canted (equal thrust split): vertical %.1f g, lift %.1f g (%.1f%%)' % (T2*(1+c)/2, m2-T2*(1+c)/2, (m2-T2*(1+c)/2)/m2*100))
print('alt. baseline: conventional stationary 4-wing cmd 1588.1 -> reduction %.1f%%, mapped thrust %.1f g' % ((1-s['sp4']/s['st4'])*100, f(s['st4'])))
print('coefficients', p)
