"""
Attitude Plot — Roll, Pitch & Yaw Rate
=======================================
Plots roll & pitch (top) and yaw rate (bottom) from a MAVLink CSV log.
X-axis is sample (row) number. Edit the CONFIG section to customise.
"""
import matplotlib
matplotlib.use('Agg')  # non-interactive backend — safe for all environments
import csv
import os
import numpy as np
import matplotlib.pyplot as plt

# ─── CONFIG ──────────────────────────────────────────────────────────────────

CSV_FILE_1 = r'c:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs/test/spin_2wings (1).csv'
CSV_FILE_2 = r'c:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs/test/clock_tilt_4_wings (4).csv'

PLOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'plots')
os.makedirs(PLOT_DIR, exist_ok=True)

DEGREES = True           # True = roll/pitch in degrees, False = radians

YLIM_ATTITUDE = None     # e.g. (-30, 30) or None for auto
YLIM_YAWRATE  = None     # e.g. (-15, 15) or None for auto

FIGSIZE = (9, 9)         # Increased height for 3 subplots
DPI     = 200

# ─── Parse CSV ────────────────────────────────────────────────────────────────

def parse_csv(csv_file, halve_attitude=False):
    """Parse a MAVLink CSV file and return attitude and servo data"""
    roll_raw, pitch_raw, yaw_rate_raw, timestamps = [], [], [], []
    servo1_raw, servo2_raw, servo8_raw, servo4_raw, servo_timestamps = [], [], [], [], []
    
    with open(csv_file, encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if len(row) < 14:
                continue
            
            # Parse ATTITUDE messages
            if row[1].strip() == 'ATTITUDE':
                try:
                    t  = float(row[0])
                    r  = float(row[10]) if row[10].strip() else None
                    p  = float(row[11]) if row[11].strip() else None
                    yr = float(row[13]) if row[13].strip() else None
                    if None not in (r, p, yr):
                        timestamps.append(t)
                        roll_val = np.degrees(r) if DEGREES else r
                        pitch_val = np.degrees(p) if DEGREES else p
                        yaw_rate_val = yr
                        
                        # Halve roll and pitch if requested (not yaw rate)
                        if halve_attitude:
                            roll_val /= 2
                            pitch_val /= 2
                        
                        roll_raw.append(roll_val)
                        pitch_raw.append(pitch_val)
                        yaw_rate_raw.append(yaw_rate_val)
                except (ValueError, IndexError):
                    continue
            
            # Parse SERVO_OUTPUT_RAW messages
            elif row[1].strip() == 'SERVO_OUTPUT_RAW':
                try:
                    t  = float(row[0])
                    s1 = float(row[5]) if row[5].strip() else None
                    s2 = float(row[6]) if row[6].strip() else None
                    s8 = float(row[7]) if row[7].strip() else None
                    s4 = float(row[8]) if row[8].strip() else None
                    if None not in (s1, s2, s8, s4):
                        servo_timestamps.append(t)
                        servo1_raw.append(s1)
                        servo2_raw.append(s2)
                        servo8_raw.append(s8)
                        servo4_raw.append(s4)
                except (ValueError, IndexError):
                    continue
    
    return (roll_raw, pitch_raw, yaw_rate_raw, timestamps,
            servo1_raw, servo2_raw, servo8_raw, servo4_raw, servo_timestamps)

# Parse both CSV files
data1 = parse_csv(CSV_FILE_1, halve_attitude=False)
data2 = parse_csv(CSV_FILE_2, halve_attitude=False)

roll_raw_1, pitch_raw_1, yaw_rate_raw_1, timestamps_1 = data1[:4]
servo1_raw_1, servo2_raw_1, servo8_raw_1, servo4_raw_1, servo_timestamps_1 = data1[4:]

roll_raw_2, pitch_raw_2, yaw_rate_raw_2, timestamps_2 = data2[:4]
servo1_raw_2, servo2_raw_2, servo8_raw_2, servo4_raw_2, servo_timestamps_2 = data2[4:]

# Find when servos engage (threshold: any servo > 100)
def find_start_index(servo1, servo2, servo8, servo4, threshold=100):
    """Find the first index where any servo exceeds threshold"""
    for i in range(len(servo1)):
        if servo1[i] > threshold or servo2[i] > threshold or servo8[i] > threshold or servo4[i] > threshold:
            return i
    return 0

servo_start_1 = find_start_index(servo1_raw_1, servo2_raw_1, servo8_raw_1, servo4_raw_1)
servo_start_2 = find_start_index(servo1_raw_2, servo2_raw_2, servo8_raw_2, servo4_raw_2)

# Calculate sample rates and create uniform time axes
# For attitude data
if timestamps_1 and len(timestamps_1) > 1:
    duration_1 = timestamps_1[-1] - timestamps_1[0]
    sample_rate_att_1 = (len(timestamps_1) - 1) / duration_1 if duration_1 > 0 else 50
else:
    sample_rate_att_1 = 50  # default Hz

if timestamps_2 and len(timestamps_2) > 1:
    duration_2 = timestamps_2[-1] - timestamps_2[0]
    sample_rate_att_2 = (len(timestamps_2) - 1) / duration_2 if duration_2 > 0 else 50
else:
    sample_rate_att_2 = 50

# Create uniform time arrays based on sample count and rate
time_1 = np.arange(len(timestamps_1)) / sample_rate_att_1 if timestamps_1 else np.array([])
time_2 = np.arange(len(timestamps_2)) / sample_rate_att_2 if timestamps_2 else np.array([])
angle_unit = 'deg' if DEGREES else 'rad'

# For servo data
if servo_timestamps_1 and len(servo_timestamps_1) > 1:
    servo_duration_1 = servo_timestamps_1[-1] - servo_timestamps_1[0]
    sample_rate_servo_1 = (len(servo_timestamps_1) - 1) / servo_duration_1 if servo_duration_1 > 0 else 50
else:
    sample_rate_servo_1 = 50

if servo_timestamps_2 and len(servo_timestamps_2) > 1:
    servo_duration_2 = servo_timestamps_2[-1] - servo_timestamps_2[0]
    sample_rate_servo_2 = (len(servo_timestamps_2) - 1) / servo_duration_2 if servo_duration_2 > 0 else 50
else:
    sample_rate_servo_2 = 50

servo_time_1 = np.arange(len(servo_timestamps_1)) / sample_rate_servo_1 if servo_timestamps_1 else np.array([])
servo_time_2 = np.arange(len(servo_timestamps_2)) / sample_rate_servo_2 if servo_timestamps_2 else np.array([])

# ─── Build time-axis ticks ───────────────────────────────────────────────────
# No longer needed since we're using time directly as x-axis


# ─── Plot ─────────────────────────────────────────────────────────────────────

fig, axes = plt.subplots(3, 1, figsize=FIGSIZE, sharex=True)
fig.suptitle(f'Hover State Time Histories Configurations I and II  (UNHALVED)', fontsize=18, fontweight='bold')

# Row 1: Roll + Pitch
ax = axes[0]
# 2-wings data (darker/saturated colors)
ax.plot(time_1, roll_raw_1,  label='Roll (2-wings)',  color='#B71C1C', linewidth=1.2)
ax.plot(time_1, pitch_raw_1, label='Pitch (2-wings)', color='#0D47A1', linewidth=1.2)
# 4-wings data (lighter/desaturated colors)
ax.plot(time_2, roll_raw_2,  label='Roll (4-wings)',  color='#D32F2F', linewidth=1.2, linestyle='--')
ax.plot(time_2, pitch_raw_2, label='Pitch (4-wings)', color='#1976D2', linewidth=1.2, linestyle='--')
ax.axhline(0, color='black', linewidth=0.5, linestyle=':')
ax.set_ylabel(f'Angle ({angle_unit})', fontsize=15)
ax.set_title('Roll & Pitch', fontsize=15)
ax.legend(fontsize=13, loc='center right', ncol=1)
ax.grid(alpha=0.25)
ax.tick_params(labelsize=14)
if YLIM_ATTITUDE:
    ax.set_ylim(YLIM_ATTITUDE)

# Row 2: Yaw rate
ax = axes[1]
ax.plot(time_1, yaw_rate_raw_1, color='#4A148C', linewidth=1.2, label='Yaw Rate (2-wings)')
ax.plot(time_2, yaw_rate_raw_2, color='#7B1FA2', linewidth=1.2, linestyle='--', label='Yaw Rate (4-wings)')
ax.axhline(0, color='black', linewidth=0.5, linestyle=':')
ax.set_ylabel('Yaw Rate (rad/s)', fontsize=15)
ax.set_title('Yaw Rate', fontsize=15)
ax.legend(fontsize=13, loc='upper right')
ax.grid(alpha=0.25)
ax.tick_params(labelsize=14)
if YLIM_YAWRATE:
    ax.set_ylim(YLIM_YAWRATE)

# Row 3: DShot values (0-2000 scale)
ax = axes[2]

# 2-wings data - Convert to percentages (solid lines)
servo1_pct_1 = [(v / 2000) * 100 for v in servo1_raw_1]
servo2_pct_1 = [(v / 2000) * 100 for v in servo2_raw_1]
servo8_pct_1 = [(v / 2000) * 100 for v in servo8_raw_1]
servo4_pct_1 = [(v / 2000) * 100 for v in servo4_raw_1]

ax.plot(servo_time_1, servo1_pct_1, label=f'Servo1 (2w)', color='#E65100', linewidth=1.2)
ax.plot(servo_time_1, servo2_pct_1, label=f'Servo2 (2w)', color='#00695C', linewidth=1.2)
ax.plot(servo_time_1, servo8_pct_1, label=f'Servo3 (2w)', color='#B71C1C', linewidth=1.2)
ax.plot(servo_time_1, servo4_pct_1, label=f'Servo4 (2w)', color='#1A237E', linewidth=1.2)

# 4-wings data - Convert to percentages (dashed lines)
servo1_pct_2 = [(v / 2000) * 100 for v in servo1_raw_2]
servo2_pct_2 = [(v / 2000) * 100 for v in servo2_raw_2]
servo8_pct_2 = [(v / 2000) * 100 for v in servo8_raw_2]
servo4_pct_2 = [(v / 2000) * 100 for v in servo4_raw_2]

ax.plot(servo_time_2, servo1_pct_2, label=f'Servo1 (4w)', color='#FF6F00', linewidth=1.2, linestyle='--')
ax.plot(servo_time_2, servo2_pct_2, label=f'Servo2 (4w)', color='#00897B', linewidth=1.2, linestyle='--')
ax.plot(servo_time_2, servo8_pct_2, label=f'Servo3 (4w)', color='#D32F2F', linewidth=1.2, linestyle='--')
ax.plot(servo_time_2, servo4_pct_2, label=f'Servo4 (4w)', color='#303F9F', linewidth=1.2, linestyle='--')

ax.set_ylabel('DShot (%)', fontsize=15)
ax.set_xlabel('Time (s)', fontsize=15)
ax.set_title('DShot Values (% of 2000)', fontsize=15)
ax.legend(fontsize=11, loc='center right', ncol=1)
ax.grid(alpha=0.25)
ax.tick_params(labelsize=14)
ax.set_ylim(0, 100)

plt.tight_layout()
out = os.path.join(PLOT_DIR, 'config1_config_2_hist_UNHALVED.png')
plt.savefig(out, dpi=DPI, bbox_inches='tight')
print(f'Saved: {out}')
