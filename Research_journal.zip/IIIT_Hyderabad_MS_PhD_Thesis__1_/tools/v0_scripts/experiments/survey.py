import csv, glob, os, numpy as np
R = r'C:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs'
dirs = ['old_data','8_17_spin','8_22_spin','8_28_spin_1cant','8_29_spin_1cant_mkill','9_09_spin_1cant','11_09_spin_1cant','test']
for d in dirs:
    for f in sorted(glob.glob(os.path.join(R,d,'*.csv'))):
        with open(f, encoding='utf-8-sig', errors='replace') as fh:
            rd = csv.reader(fh); hdr = next(rd); rows = [r for r in rd if len(r) > 2]
        ts = []
        for r in rows:
            try: ts.append(float(r[0]))
            except: pass
        ts = np.array(ts)
        if len(ts) < 2: print(d, os.path.basename(f), 'empty'); continue
        intres = np.all(np.mod(ts,1)==0)
        n_att = sum(1 for r in rows if r[1]=='ATTITUDE'); n_srv = sum(1 for r in rows if r[1]=='SERVO_OUTPUT_RAW')
        dur = ts.max()-ts.min()
        print(f"{d:24s} {os.path.basename(f):38s} dur={dur:7.1f}s int_ts={intres} att/s={n_att/dur:5.1f} srv/s={n_srv/dur:5.1f} rows/s={len(rows)/dur:6.1f} hdr_yawrate={'Yaw Rate (rad/s)' in hdr} cols={len(hdr)}")
