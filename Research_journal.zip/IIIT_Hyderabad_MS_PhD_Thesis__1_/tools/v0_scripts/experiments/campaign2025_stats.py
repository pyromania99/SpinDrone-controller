"""Agent D scratch analysis: summary statistics of the 2025 MAVLink CSV logs (read-only).
- Integer-second timestamps (some logs) are spread uniformly within each second, per message type.
- Yaw rate is derived from the unwrapped ATTITUDE yaw (as in parsing_scripts/calculate_yaw_rate.py),
  then smoothed by a least-squares slope over a centred 1-s window (raw finite differences are noisy).
- 'Active' = SERVO_OUTPUT_RAW samples with mean command > 300 (idle is about 199) (or ATTITUDE span if no servo messages).
- Steady yaw rate = median of the smoothed yaw rate over the active span; peak = max |smoothed yaw rate|.
- Roll/pitch RMS over the active span; saturation = fraction of active servo samples with any output >= 1990."""
import csv, glob, os, sys, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
R = r'C:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs'
def spread(ts):
    ts = np.asarray(ts, float)
    if len(ts) == 0 or not np.all(np.mod(ts, 1) == 0): return ts
    out = ts.copy(); u, idx, cnt = np.unique(ts, return_inverse=True, return_counts=True)
    k = np.zeros(len(ts));
    seen = {}
    for i, v in enumerate(ts):
        seen[v] = seen.get(v, -1) + 1; k[i] = seen[v]
    return ts + k / cnt[idx]
def load_csv(fp):
    att, srv = [], []
    with open(fp, encoding='utf-8-sig', errors='replace') as f:
        rd = csv.reader(f); hdr = next(rd)
        for r in rd:
            if len(r) < 13: continue
            try: t = float(r[0])
            except: continue
            if r[1] == 'ATTITUDE':
                try: att.append((t, float(r[10]), float(r[11]), float(r[12])))
                except: pass
            elif r[1] == 'SERVO_OUTPUT_RAW':
                try: srv.append((t, *[float(x) for x in r[5:9]]))
                except: pass
    return np.array(att), np.array(srv)
def load_xlsx_sheet(fp, sheet):
    import read_xlsx
    out, _ = read_xlsx.read(fp)
    att, srv = [], []
    for cells in out[sheet][1:]:
        d = {''.join(ch for ch in r if ch.isalpha()): v for r, v, f in cells}
        try: t = float(d['A'])
        except: continue
        if d.get('B') == 'ATTITUDE':
            try: att.append((t, float(d['K']), float(d['L']), float(d['M'])))
            except: pass
        elif d.get('B') == 'SERVO_OUTPUT_RAW':
            try: srv.append((t, *[float(d[c]) for c in 'FGHI']))
            except: pass
    return np.array(att), np.array(srv)
def stats(name, att, srv):
    if len(att) < 10: print(f'{name}: no attitude'); return
    ta = spread(att[:,0]); yaw = np.unwrap(att[:,3])
    if len(srv): ts = spread(srv[:,0]); cmd = srv[:,1:5]; act = cmd.mean(1) > 300
    else: ts = np.array([]); act = np.array([], bool)
    if act.any(): t0, t1 = ts[act][0], ts[act][-1]
    else: t0, t1 = ta[0], ta[-1]
    # smoothed yaw rate: slope over centred 1 s window
    yr = np.full(len(ta), np.nan)
    for i in range(len(ta)):
        m = np.abs(ta - ta[i]) <= 0.5
        if m.sum() >= 4: yr[i] = np.polyfit(ta[m], yaw[m], 1)[0]
    ma = (ta >= t0) & (ta <= t1) & ~np.isnan(yr)
    if ma.sum() < 5: print(f"{name}: too short"); return
    rate = len(ta) / (ta[-1] - ta[0])
    sat = (np.any(cmd[act] >= 1990, axis=1).mean() * 100) if act.any() else np.nan
    sat_s = (np.any(cmd[act] >= 1990, axis=1).sum() / max(1e-9, act.sum()) * (t1 - t0)) if act.any() else np.nan
    rot = (yaw[ma][-1] - yaw[ma][0]) / (2*np.pi) if ma.any() else np.nan
    print(f"{name:52s} log={ta[-1]-ta[0]:6.1f}s active={t1-t0:6.1f}s att_rate={rate:5.1f}/s srv_n={len(srv):5d} "
          f"yr_med={np.nanmedian(yr[ma]):6.2f} yr_peak={np.nanmax(np.abs(yr[ma])):6.2f} revs={rot:6.1f} "
          f"roll_rms={np.degrees(np.sqrt(np.mean(att[ma,1]**2))):5.2f} pitch_rms={np.degrees(np.sqrt(np.mean(att[ma,2]**2))):5.2f} "
          f"sat%={sat:5.1f} sat_s={sat_s:5.1f} cmd_med={np.median(cmd[act].mean(1)) if act.any() else np.nan:6.0f}")
    return dict(ta=ta, yr=yr, att=att, ts=ts, srv=srv)
if __name__ == '__main__':
    for d in ['8_17_spin','8_22_spin','8_28_spin_1cant','8_29_spin_1cant_mkill','9_09_spin_1cant','11_09_spin_1cant']:
        for f in sorted(glob.glob(os.path.join(R, d, '*.csv'))):
            att, srv = load_csv(f)
            stats(d + '/' + os.path.basename(f), att, srv)
    for f in ['old_data/mavlink_data_spin1.csv','old_data/mavlink_data_rest.csv','old_data/mavlink_data_run2.csv']:
        att, srv = load_csv(os.path.join(R, f)); stats(f, att, srv)
    att, srv = load_xlsx_sheet(os.path.join(R, 'old_data', 'mavlink_data_spin2.xlsx'), 'mavlink_data_spin2') if False else (None, None)
