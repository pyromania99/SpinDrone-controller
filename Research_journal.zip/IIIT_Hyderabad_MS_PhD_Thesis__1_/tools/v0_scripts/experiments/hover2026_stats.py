"""Agent D scratch analysis: re-derive the Feb-2026 hover statistics.
Reproduces analyze_hover.py's stable-window selection (all four motor commands > 1000,
centred rolling std of the 4-motor mean over 10 SERVO_OUTPUT_RAW samples < 80, longest run)
and adds yaw-rate / attitude statistics inside that window. Read-only on the workspace."""
import csv, os, numpy as np
T = r'C:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs/test'
GROUPS = {
 'stationary_4wing': ['stationary_4_wing.csv'],
 'all_clock_4wing': ['all_clock_4_wing.csv'],
 'clock_tilt_4wing': ['clock_tilt_4_wings (1).csv','clock_tilt_4_wings (2).csv','clock_tilt_4_wings (3).csv','clock_tilt_4_wings (4).csv'],
 'stationary_2wing': ['stationary_2wing (1).csv','stationary_2wing (2).csv'],
 'spin_2wing': ['spin_2wings (1).csv','spin_2wings (2).csv'],
 'extra': ['clock_tilt_4_wing (5).csv','4_wing_crash.csv','mavlink_data_20260227_103936.csv','mavlink_data_20260227_112824.csv','mavlink_data_20260227_225745.csv','mavlink_data_20260228_010411.csv','mavlink_data_20260228_013010.csv'],
}
def parse(fp):
    srv, att = [], []
    with open(fp, encoding='utf-8-sig') as f:
        rd = csv.reader(f); next(rd)
        for r in rd:
            if len(r) < 10: continue
            try: ts = float(r[0])
            except: continue
            if r[1] == 'SERVO_OUTPUT_RAW':
                try: srv.append((ts, int(r[5]), int(r[6]), int(r[7]), int(r[8])))
                except: pass
            elif r[1] == 'ATTITUDE' and len(r) > 13:
                try: att.append((ts, float(r[10]), float(r[11]), float(r[12]), float(r[13])))
                except: pass
    return np.array(srv, float), np.array(att, float)
def stable(srv, min_servo=1000, window=10, thr=80):
    a = srv[np.all(srv[:,1:5] > min_servo, axis=1)]
    if len(a) < window + 2: return a, 'short'
    avg = a[:,1:5].mean(1)
    rs = np.array([np.std(avg[max(0,i-window//2):i+window//2+1]) for i in range(len(avg))])
    best = (0,0); cs = 0; cl = 0
    for i, ok in enumerate(rs < thr):
        if ok:
            if cl == 0: cs = i
            cl += 1
            if cl > best[1]: best = (cs, cl)
        else: cl = 0
    if best[1] < 3:
        n = len(a); return a[n//5:4*n//5], 'fallback'
    return a[best[0]:best[0]+best[1]], 'ok'
res = {}
for g, files in GROUPS.items():
    allavg = []
    for fn in files:
        srv, att = parse(os.path.join(T, fn))
        if len(srv) == 0: print(g, fn, 'no servo'); continue
        st, how = stable(srv)
        avg = st[:,1:5].mean(1); allavg += list(avg)
        t0, t1 = st[0,0], st[-1,0]
        act = srv[np.any(srv[:,1:5] > 100, axis=1)]
        m = (att[:,0] >= t0) & (att[:,0] <= t1)
        ma = (att[:,0] >= act[0,0]) & (att[:,0] <= act[-1,0]) if len(act) else m
        yr = att[:,4]
        print(f"{g:17s} {fn:34s} win={how:8s} n_srv={len(st):3d} win_s={t1-t0:5.1f} mean_cmd={avg.mean():7.1f} sd={avg.std():5.1f} "
              f"per_motor={np.round(st[:,1:5].mean(0)).astype(int)} | yawrate_win mean_abs={np.mean(np.abs(yr[m])) if m.any() else np.nan:6.2f} "
              f"| active: dur={act[-1,0]-act[0,0] if len(act) else 0:5.1f}s peak|yr|={np.abs(yr[ma]).max() if ma.any() else np.nan:5.2f} "
              f"roll_rms={np.degrees(np.sqrt(np.mean(att[m,1]**2))) if m.any() else np.nan:5.2f}deg pitch_rms={np.degrees(np.sqrt(np.mean(att[m,2]**2))) if m.any() else np.nan:5.2f}deg "
              f"max_cmd={int(srv[:,1:5].max())}")
    if allavg and g != 'extra': res[g] = (np.mean(allavg), np.std(allavg), len(allavg))
print()
for g, v in res.items(): print(f"{g:17s} mean={v[0]:.1f} std={v[1]:.1f} n={v[2]}")
s_low, t_low = 1050, 450
s_mid, s_high = res['stationary_2wing'][0], res['all_clock_4wing'][0]
p = np.polyfit([s_low, s_mid, s_high], [t_low, 658, 960], 2); f = np.poly1d(p)
print('quadratic coeffs a,b,c =', p)
for g, mass, tilt, nw in [('all_clock_4wing',960,0,4),('clock_tilt_4wing',960,10,4),('stationary_2wing',658,0,2),('spin_2wing',658,0,2),('stationary_4wing',960,0,4)]:
    s = res[g][0]; T_ = f(s); V = T_*np.cos(np.radians(tilt)); L = mass - V
    print(f"{g:17s} cmd={s:7.1f} thrust={T_:6.1f}g vert={V:6.1f}g lift={L:6.1f}g ({L/mass*100:4.1f}%) per_wing={L/nw:5.1f}g")
print('cmd reduction 4w: %.1f%%  2w: %.1f%%' % ((1-res['clock_tilt_4wing'][0]/res['all_clock_4wing'][0])*100, (1-res['spin_2wing'][0]/res['stationary_2wing'][0])*100))
# bench table check
bx = np.array([379,559,739,919,1099,1459,1639]); by = np.array([32,51.28,83,117,151,222,255])
i1050 = np.interp(1050, bx, by); lin = np.polyfit(bx, by, 1)
print('bench per-motor at 1050 (interp) = %.1f g, x4 = %.1f g; linear fit slope %.4f g/unit, intercept %.1f g -> at 1050: %.1f g' % (i1050, 4*i1050, lin[0], lin[1], np.polyval(lin,1050)))
for s in [1133, 1339, 1487, 1809]:
    print(' bench interp x4 at', s, '=', round(4*np.interp(s, bx, by),1), 'g ; mapping =', round(f(s),1), 'g')
