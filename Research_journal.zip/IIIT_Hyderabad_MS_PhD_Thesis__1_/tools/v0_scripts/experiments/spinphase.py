"""Agent D: spin-phase statistics for the 2025 logs (uses campaign2025_stats loaders).
Spin phase = ATTITUDE samples whose 1-s smoothed yaw rate |r| > 2 rad/s.
Reported: log length, spin-phase duration, median and 95th-percentile |r| in the spin phase, peak |r|,
roll/pitch RMS in the spin phase, % of servo samples in the spin phase with any output >= 1990,
largest ATTITUDE gap, and the aliasing limit pi*f_att on a yaw rate derived from yaw."""
import glob, os, numpy as np
from campaign2025_stats import load_csv, spread, R
def run(name, att, srv):
    if len(att) < 20: return
    ta = spread(att[:,0]); yaw = np.unwrap(att[:,3])
    yr = np.full(len(ta), np.nan)
    for i in range(len(ta)):
        m = np.abs(ta - ta[i]) <= 0.5
        if m.sum() >= 4: yr[i] = np.polyfit(ta[m], yaw[m], 1)[0]
    sp = np.abs(yr) > 2
    fs = len(ta)/(ta[-1]-ta[0]); gap = np.max(np.diff(ta))
    if sp.sum() < 5:
        print(f"{name:50s} log={ta[-1]-ta[0]:6.1f}s spin=  none  f_att={fs:5.1f}"); return
    # spin duration = sum of dt within spin samples
    dt = np.minimum(np.diff(ta, append=ta[-1]), 0.5); dur = dt[sp].sum()  # gaps capped at 0.5 s
    a = np.abs(yr[sp])
    sat = np.nan; cmdmed = np.nan
    if len(srv):
        ts = spread(srv[:,0]); ins = np.interp(ts, ta, sp.astype(float)) > 0.5
        if ins.any():
            sat = np.any(srv[ins,1:5] >= 1990, axis=1).mean()*100; cmdmed = np.median(srv[ins,1:5].mean(1))
    print(f"{name:50s} log={ta[-1]-ta[0]:6.1f}s spin={dur:6.1f}s r_med={np.median(a):5.2f} r_p95={np.percentile(a,95):5.2f} r_peak={a.max():5.2f} "
          f"roll_rms={np.degrees(np.sqrt(np.mean(att[sp,1]**2))):5.2f} pitch_rms={np.degrees(np.sqrt(np.mean(att[sp,2]**2))):5.2f} sat%={sat:5.1f} cmd_med={cmdmed:6.0f} f_att={fs:5.1f} alias={np.pi*fs:5.1f} maxgap={gap:4.2f}s")
for d in ['8_17_spin','8_22_spin','8_28_spin_1cant','8_29_spin_1cant_mkill','9_09_spin_1cant','11_09_spin_1cant']:
    for f in sorted(glob.glob(os.path.join(R, d, '*.csv'))):
        att, srv = load_csv(f); run(d+'/'+os.path.basename(f), att, srv)
for f in ['old_data/mavlink_data_spin1.csv','old_data/mavlink_data_run2.csv','old_data/mavlink_data_rest.csv']:
    att, srv = load_csv(os.path.join(R, f)); run(f, att, srv)
