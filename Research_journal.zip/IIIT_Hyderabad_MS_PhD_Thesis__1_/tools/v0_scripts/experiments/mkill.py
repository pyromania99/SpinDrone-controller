"""Agent D: 2-s binned timeline of the 29 Aug 2025 motor-kill log."""
import os, numpy as np
from campaign2025_stats import load_csv, spread, R
att, srv = load_csv(os.path.join(R, '8_29_spin_1cant_mkill', 'mavlink_data_20250829_201457.csv'))
ta = spread(att[:,0]); yaw = np.unwrap(att[:,3]); ts = spread(srv[:,0])
t0 = ts[0]
for b in np.arange(0, ts[-1]-t0, 2.0):
    m = (ts-t0 >= b) & (ts-t0 < b+2); ma = (ta-t0 >= b) & (ta-t0 < b+2)
    if not m.any() or srv[m,1:5].max() < 250: continue
    r = np.polyfit(ta[ma], yaw[ma], 1)[0] if ma.sum() > 3 else np.nan
    print(f"t={b:5.0f} cmd={np.round(srv[m,1:5].mean(0)).astype(int)} max={srv[m,1:5].max(0).astype(int)} r={r:6.2f} roll={np.degrees(np.abs(att[ma,1]).max()):5.1f} pitch={np.degrees(np.abs(att[ma,2]).max()):5.1f}")
