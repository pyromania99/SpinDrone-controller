"""Minimal xlsx reader (zipfile + XML) -- prints every non-empty cell of every sheet."""
import sys, zipfile, re
import xml.etree.ElementTree as ET
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def read(path, maxrows=None):
    z = zipfile.ZipFile(path)
    names = z.namelist()
    ss = []
    if 'xl/sharedStrings.xml' in names:
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root.findall('m:si', NS):
            ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    sheets = [s.get('name') for s in wb.find('m:sheets', NS)]
    out = {}
    files = sorted([n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml', n)], key=lambda s: int(re.findall(r'\d+', s)[-1]))
    for name, f in zip(sheets, files):
        root = ET.fromstring(z.read(f))
        rows = []
        for r in root.iter('{%s}row' % NS['m']):
            cells = []
            for c in r.findall('m:c', NS):
                v = c.find('m:v', NS); fo = c.find('m:f', NS)
                t = c.get('t'); val = v.text if v is not None else None
                if t == 's' and val is not None: val = ss[int(val)]
                elif t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
                cells.append((c.get('r'), val, fo.text if fo is not None else None))
            rows.append(cells)
            if maxrows and len(rows) >= maxrows: break
        out[name] = rows
    charts = [n for n in names if 'chart' in n or 'drawing' in n]
    return out, charts
if __name__ == '__main__':
    out, charts = read(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else None)
    print('charts/drawings:', charts)
    for name, rows in out.items():
        print('=== sheet', name, len(rows), 'rows')
        for cells in rows:
            print('  ', [(r, v, f) if f else (r, v) for r, v, f in cells if v is not None or f])
