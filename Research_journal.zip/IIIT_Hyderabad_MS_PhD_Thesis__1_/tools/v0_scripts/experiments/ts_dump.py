import csv, sys, os, numpy as np
T = r'C:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs/test'
for fn in sys.argv[1:]:
    srv=[]; alt=[]; att=[]
    with open(os.path.join(T,fn), encoding='utf-8-sig') as f:
        rd=csv.reader(f); next(rd)
        for r in rd:
            if len(r)<10: continue
            try: ts=float(r[0])
            except: continue
            if r[1]=='SERVO_OUTPUT_RAW':
                try: srv.append((ts,*[int(x) for x in r[5:9]]))
                except: pass
            elif r[1]=='ALTITUDE':
                try: alt.append((ts,float(r[9])))
                except: pass
            elif r[1]=='ATTITUDE':
                try: att.append((ts,float(r[13])))
                except: pass
    srv=np.array(srv,float); alt=np.array(alt); att=np.array(att)
    t0=srv[0,0]
    print('==',fn)
    # bucket into 2-s bins
    for b in np.arange(0, srv[-1,0]-t0+2, 2.0):
        m=(srv[:,0]-t0>=b)&(srv[:,0]-t0<b+2)
        ma=(alt[:,0]-t0>=b)&(alt[:,0]-t0<b+2) if len(alt) else np.array([])
        my=(att[:,0]-t0>=b)&(att[:,0]-t0<b+2)
        if m.any() and srv[m,1:].max()>100:
            print(f" t={b:5.0f}s cmd={np.round(srv[m,1:].mean(0)).astype(int)} avg={srv[m,1:].mean():6.0f} alt={alt[ma,1].mean() if ma.any() else float('nan'):7.2f} yr={att[my,1].mean() if my.any() else float('nan'):5.2f}")
