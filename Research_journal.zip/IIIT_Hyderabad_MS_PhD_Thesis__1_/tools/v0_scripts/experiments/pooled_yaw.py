"""Agent D: pooled mean |yaw rate| in the stabilised windows (as analyze_hover.py: mean of |ATTITUDE.yawspeed| pooled over files)."""
import os, numpy as np
from hover2026_stats import parse, stable, GROUPS, T
for g in ['all_clock_4wing','clock_tilt_4wing','stationary_2wing','spin_2wing','stationary_4wing']:
    yrs=[]
    for fn in GROUPS[g]:
        srv, att = parse(os.path.join(T, fn)); st,_ = stable(srv)
        m = (att[:,0] >= st[0,0]) & (att[:,0] <= st[-1,0]); yrs += list(np.abs(att[m,4]))
    w = np.mean(yrs); print(f"{g:18s} pooled mean |wz| = {w:.2f} rad/s (n={len(yrs)})  w^2={w*w:.1f}")
