"""Agent D: BATTERY_STATUS samples (V, A) that fall inside the active span (all four commands > 1000) of each Feb-2026 hover log."""
import csv, os, numpy as np
T = r'C:/Users/anike/Desktop/RESEARCH/spin_drone/06_experiments/telemetry/raw_logs/test'
G = {'all_clock_4wing':['all_clock_4_wing.csv'],'stationary_4wing':['stationary_4_wing.csv'],
     'clock_tilt_4wing':['clock_tilt_4_wings (%d).csv'%i for i in (1,2,3,4)],
     'stationary_2wing':['stationary_2wing (1).csv','stationary_2wing (2).csv'],'spin_2wing':['spin_2wings (1).csv','spin_2wings (2).csv']}
for g, fs in G.items():
    for fn in fs:
        srv=[]; bat=[]
        for r in csv.reader(open(os.path.join(T,fn), encoding='utf-8-sig')):
            if len(r) < 9: continue
            try: t=float(r[0])
            except: continue
            if r[1]=='SERVO_OUTPUT_RAW': srv.append((t,*map(int,r[5:9])))
            elif r[1]=='BATTERY_STATUS': bat.append((t,float(r[2]),float(r[3])))
        srv=np.array(srv); bat=np.array(bat)
        act=srv[np.all(srv[:,1:]>1000,axis=1)]
        if len(act)==0: print(g,fn,'no active'); continue
        m=(bat[:,0]>=act[0,0]-1)&(bat[:,0]<=act[-1,0]+1)
        print(f"{g:17s} {fn:28s} battery samples in active span: {[(round(v,2),round(a,1),round(v*a)) for _,v,a in bat[m]]}  (all samples {len(bat)}, interval {np.mean(np.diff(bat[:,0])):.1f}s)")
