"""Agent D: quick statistics of the Aug 2025 hover workbooks and yaw_dat files."""
import os, numpy as np, datetime
from campaign2025_stats import load_xlsx_sheet, R
from spinphase import run
import read_xlsx
for f, sh in [('stable_hover_7_8_25.xlsx','mavlink_dqata'), ('Normal_hover_yaw_disp.xlsx','mavlink_data')]:
    att, srv = load_xlsx_sheet(os.path.join(R, f), sh)
    print('==', f, datetime.datetime.fromtimestamp(att[0,0], datetime.UTC))
    run(f, att, srv)
    act = srv[:,1:5].mean(1) > 300
    print('   active cmd median per motor', np.median(srv[act,1:5], axis=0), 'n', act.sum())
for f in sorted(os.listdir(os.path.join(R,'yaw_dat'))):
    if not f.endswith('.xlsx'): continue
    out,_ = read_xlsx.read(os.path.join(R,'yaw_dat',f)); rows = out['Sheet1']
    hdr = [v for r,v,_ in rows[0]]
    data = np.array([[float(v) if v not in (None,'') else np.nan for r,v,_ in cells if r[0] not in 'B'] for cells in rows[1:]], dtype=object)
    t = np.array([float(cells[0][1]) for cells in rows[1:]]); yaw = np.array([float(cells[2][1]) for cells in rows[1:]])
    cols = {h: np.array([float(c[i][1]) for c in rows[1:] if len(c) > i]) for i, h in enumerate(hdr) if h not in ('DateTime',)}
    yu = np.unwrap(np.radians(yaw))
    print(f, hdr, 'dur %.1f s n %d rate %.1f/s' % (t[-1]-t[0], len(t), len(t)/(t[-1]-t[0])), 'yaw rate avg %.2f rad/s' % ((yu[-1]-yu[0])/(t[-1]-t[0])),
          {k: (round(float(np.nanmin(v)),2), round(float(np.nanmax(v)),2)) for k, v in cols.items() if k not in ('Timestamp',)})
