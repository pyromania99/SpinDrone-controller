import numpy as np
def T(ph,th):
    return np.array([[1,np.sin(ph)*np.tan(th),np.cos(ph)*np.tan(th)],[0,np.cos(ph),-np.sin(ph)],[0,np.sin(ph)/np.cos(th),np.cos(ph)/np.cos(th)]])
def H(ph,th,phd,thd,a,r):
    A=np.array([[-a,r,0],[-r,-a,0],[0,0,0]])
    h=1e-7
    Td=(T(ph+h*phd,th+h*thd)-T(ph,th))/h
    Ti=np.linalg.inv(T(ph,th))
    return Td@Ti + T(ph,th)@A@Ti
a,r=0.3,9.0
e=1e-3
ph,th,phd,thd=0.7*e,0.4*e,1.1*e,-0.6*e
Hx=H(ph,th,phd,thd,a,r)
Hfo=np.array([[-a, r+phd*th, thd+a*th+r*ph],[-r,-a, r*th-a*ph-phd],[-r*ph, phd-a*ph, 0]])
np.set_printoptions(precision=3,suppress=True)
print((Hx-Hfo)/e)   # should be O(e) -> small
print(np.linalg.eigvals(Hx))
# perturbation prediction
print(-a, r+0.5*phd*th)
# check whether H_fo first order terms right by finite diff in e
Hx2=H(2*ph,2*th,2*phd,2*thd,a,r)
H0=H(0,0,0,0,a,r)
print("first-order coeff:\n",(Hx-H0)/e)
print("---- second-order check")
for e in [1e-2,3e-2,1e-1]:
    ph,th,phd,thd=0.7*e,0.4*e,1.1*e,-0.6*e
    Hx=H(ph,th,phd,thd,a,r)
    ev=np.linalg.eigvals(Hx); lp=ev[np.argmax(ev.imag)]
    d=Hx-H(0,0,0,0,a,r)
    lam0=-a+1j*r
    s2=(d[0,2]-1j*d[1,2])*(d[2,0]+1j*d[2,1])/(2*lam0)
    s1=(d[0,0]-1j*d[1,0]+1j*d[0,1]+d[1,1])/2
    print(e, "exact shift", lp-lam0, " 1/2 phd*th*j:", 0.5j*phd*th, " first-order(full):", s1, " yaw-mode 2nd:", s2, " sum:", s1+s2)
    print("   third eig exact", ev[np.argmin(abs(ev))], " theta*thetadot", th*thd)
