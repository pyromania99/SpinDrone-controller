exec(open('oop_check.py',encoding='utf-8').read().split('# Find optimal operating points for each airfoil at each Re')[0])
import numpy as np
for re_, g in full_df.groupby('Re'):
    g=g.copy(); g['LD']=g.CL/g.CD; g=g[np.isfinite(g.LD)]
    mcl,mld,mcp,xcp=g.CL.max(),g.LD.max(),g.Cpmin.min(),g.Cpmin.max()
    g['J']=0.5*g.LD/mld+0.3*g.CL/mcl+0.2*g.Cpmin/mcp
    g['Jinv']=0.5*g.LD/mld+0.3*g.CL/mcl+0.2*(1-g.Cpmin/mcp)
    g['J80']=0.5*g.LD/mld+0.3*g.CL/mcl   # no Cp term
    out=[]
    for af,a in g.groupby('Airfoil'):
        i=a.J.idxmax(); j=a.Jinv.idxmax(); k=a.J80.idxmax()
        out.append((af,a.loc[i,'J'],a.loc[i,'alpha'],a.loc[j,'Jinv'],a.loc[j,'alpha'],a.loc[j,'CL'],a.loc[j,'LD'],a.loc[k,'alpha']))
    print(f"Re {re_}")
    for o in sorted(out,key=lambda x:-x[3]): pass
    print("  noCp ranking:", [(o2[0], round(o2[1],3)) for o2 in sorted([(af, a.J80.max()) for af,a in g.groupby("Airfoil")], key=lambda x:-x[1])][:3])
    if False: print(f"   {o[0]:15s} J={o[1]:.3f}@{o[2]:4.1f} | Jinv={o[3]:.3f}@{o[4]:4.1f} Cl={o[5]:.2f} LD={o[6]:.1f} | noCp@{o[7]:4.1f}")
