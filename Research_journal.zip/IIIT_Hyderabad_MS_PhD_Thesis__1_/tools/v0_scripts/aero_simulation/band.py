import numpy as np
P=r"C:/Users/anike/Desktop/RESEARCH/spin_drone/03_simulation/mujoco/polars/"
def load(n):
    L=open(P+n,encoding='utf-8').read().splitlines()
    i=[k for k,l in enumerate(L) if 'alpha' in l and 'CL' in l][0]+2
    a=np.array([[float(x) for x in l.split()[:3]] for l in L[i:] if len(l.split())>=3])
    return a
for re_ in ['0.040','0.060','0.080','0.100','0.130']:
    for af in ['franky','franky 2','SD7037-092-88','S1223','NACA 4412','AG14','RG-15 8.9%','RG 14 AIRFOIL','SD7032-099-88','SD7062 (14%)']:
        try: a=load(f"{af}_T1_Re{re_}_M0.00_N9.0.txt")
        except Exception as e: continue
        a=a[a[:,0]<=15]
        ld=a[:,1]/a[:,2]; m=ld.max(); am=a[ld.argmax(),0]
        sel=a[ld>=0.9*m,0]
        print(f"Re {re_} {af:14s} maxLD {m:5.1f} at {am:4.1f}  90%-band {sel.min():4.1f}-{sel.max():4.1f} (width {sel.max()-sel.min():4.1f})  Clmax {a[:,1].max():.2f}")
