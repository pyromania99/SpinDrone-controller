import re, numpy as np
from pathlib import Path
from collections import defaultdict
WS=Path(r"C:/Users/anike/Desktop/RESEARCH/spin_drone/03_simulation/mujoco")
RHO=1.225; MU=1.81e-5
rows=[l.split('\t') for l in open(WS/'results/optimized_design.txt',encoding='utf-8').read().splitlines()[1:] if l.strip()]
R=[];C=[];CL=[];CD=[];A=[];AF=[]
for p in rows:
    p=[x.strip() for x in p if x.strip()!='']
    R.append(float(p[0]));AF.append(p[3]);A.append(float(p[4]));C.append(float(p[5]));CL.append(float(p[6]));CD.append(float(p[6])/float(p[7]))
R=np.array(R);C=np.array(C);CL=np.array(CL);CD=np.array(CD);A=np.array(A)
pol=defaultdict(dict)
for f in (WS/'polars').glob('*.txt'):
    m=re.search(r'(.+?)_T1_Re([0-9.]+)_M',f.name)
    if not m: continue
    lines=open(f,encoding='utf-8').read().splitlines()
    ds=0
    for i,l in enumerate(lines):
        if 'alpha' in l and 'CL' in l and 'CD' in l: ds=i+2;break
    d={}
    for l in lines[ds:]:
        q=l.split()
        if len(q)>=3:
            try:d[float(q[0])]=(float(q[1]),float(q[2]))
            except:pass
    if d: pol[m.group(1).strip()][float(m.group(2))]=d
def ia(d,a):
    al=sorted(d); a=np.clip(a,al[0],al[-1])
    for i in range(len(al)-1):
        if al[i]<=a<=al[i+1]:
            f=(a-al[i])/(al[i+1]-al[i]); l=d[al[i]];h=d[al[i+1]]
            return l[0]+f*(h[0]-l[0]), l[1]+f*(h[1]-l[1])
    return d[al[0]]
def lk(af,Re,a):
    key=[k for k in pol if k.replace(' ','').lower()==af.replace(' ','').lower()]
    if not key: return None,None
    rd=pol[key[0]]; rs=sorted(rd)
    if Re<=rs[0]: return ia(rd[rs[0]],a)
    if Re>=rs[-1]: return ia(rd[rs[-1]],a)
    for i in range(len(rs)-1):
        if rs[i]<=Re<=rs[i+1]:
            l=ia(rd[rs[i]],a);h=ia(rd[rs[i+1]],a);f=(Re-rs[i])/(rs[i+1]-rs[i])
            return l[0]+f*(h[0]-l[0]), l[1]+f*(h[1]-l[1])
n=30; rf=np.linspace(R.min(),R.max(),n)
cf=np.interp(rf,R,C);clf=np.interp(rf,R,CL);cdf=np.interp(rf,R,CD);af=np.interp(rf,R,A)
aff=[AF[np.argmin(abs(R-r))] for r in rf]
dr=np.array([(rf[1]-rf[0])/2 if i==0 else max((rf[i]-rf[i-1])/2,0.001) if i==n-1 else (rf[i+1]-rf[i-1])/2 for i in range(n)])
def forces(om,dynamic=True,vi=0.5,site_offset=0.0):
    Ad=np.pi*R.max()**2
    for it in range(200):
        T=0;Q=0;Qs=0
        for i,r in enumerate(rf):
            Vt=om*r; Va=vi*(1-0.3*(r/0.65)**2); V=np.hypot(Vt,Va)
            Re=RHO*V*cf[i]/MU/1e6; phi=np.arctan2(Va,Vt)
            cl,cd=(lk(aff[i],Re,af[i]) if dynamic else (None,None))
            if cl is None: cl,cd=clf[i],cdf[i]
            q=0.5*RHO*V**2; cdi=cl**2/(np.pi*(2*r/cf[i])*0.85)
            dL=q*cf[i]*cl*dr[i]; dD=q*cf[i]*(cd+cdi)*dr[i]
            dT=dL*np.cos(phi)-dD*np.sin(phi); dF=dL*np.sin(phi)+dD*np.cos(phi)
            T+=dT;Q+=dF*r
        T*=4;Q*=4
        vn=np.sqrt(T/(2*RHO*Ad)) if T>0 else 0
        if abs(vn-vi)<1e-6: break
        vi=0.5*vi+0.5*vn
    return T,Q,vi
for om in [8.0,9.157,9.27,10.0]:
    print(om,'dyn',[round(x,4) for x in forces(om,True)],'fixed',[round(x,4) for x in forces(om,False)])
# Re range on span at 9.27
print('Re span at 9.27:',[round(RHO*9.27*r*c/MU) for r,c in zip(R,C)])

def applied_torque(om):
    T,Q,vi=forces(om,True)
    # recompute per-section dF_tan at converged vi
    dF=[]
    for i,r in enumerate(rf):
        Vt=om*r; Va=vi*(1-0.3*(r/0.65)**2); V=np.hypot(Vt,Va)
        Re=RHO*V*cf[i]/MU/1e6; phi=np.arctan2(Va,Vt)
        cl,cd=lk(aff[i],Re,af[i])
        if cl is None: cl,cd=clf[i],cdf[i]; print("fallback",i,aff[i])
        q=0.5*RHO*V**2; cdi=cl**2/(np.pi*(2*r/cf[i])*0.85)
        dL=q*cf[i]*cl*dr[i]; dD=q*cf[i]*(cd+cdi)*dr[i]
        dF.append(dL*np.sin(phi)+dD*np.cos(phi))
    rs=0.4+np.array([0.042,0.092,0.142,0.192,0.242,0.292])
    Qs=sum(sum(dF[k*5:(k+1)*5])*rs[k] for k in range(6))*4
    return Q,Qs
for om in (9.157,9.27):
    print(om, applied_torque(om))
print('phi at 9.27:',[round(np.degrees(np.arctan2(1.2735*(1-0.3*(r/0.65)**2),9.27*r)),1) for r in (0.40,0.45,0.5,0.55,0.6,0.65)])

def decomp(om):
    T,Q,vi=forces(om,True)
    Qi=Qp=Qd=0; L=0; secs=[]
    for i,r in enumerate(rf):
        Vt=om*r; Va=vi*(1-0.3*(r/0.65)**2); V=np.hypot(Vt,Va)
        Re=RHO*V*cf[i]/MU; phi=np.arctan2(Va,Vt)
        cl,cd=lk(aff[i],Re/1e6,af[i])
        if cl is None: cl,cd=clf[i],cdf[i]
        q=0.5*RHO*V**2; cdi=cl**2/(np.pi*(2*r/cf[i])*0.85)
        dL=q*cf[i]*cl*dr[i]
        Qi+=dL*np.sin(phi)*r; Qp+=q*cf[i]*cd*dr[i]*np.cos(phi)*r; Qd+=q*cf[i]*cdi*dr[i]*np.cos(phi)*r
        secs.append((round(r,3),round(Re),aff[i],round(cl,3),round(cd,4),round(cdi,4),round(np.degrees(phi),1)))
    print('Q total',4*(Qi+Qp+Qd),'inflow-tilt',4*Qi,'profile',4*Qp,'induced-drag term',4*Qd)
    for s in secs[::5]+[secs[-1]]: print(s)
decomp(9.27)
