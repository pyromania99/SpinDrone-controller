exec(open('oop_check.py',encoding='utf-8').read().split('# Create the plot')[0])
import sys
for af in sorted(airfoil_re_details):
    s=[]
    for re_ in sorted(airfoil_re_details[af]):
        d=airfoil_re_details[af][re_]
        s.append(f"{re_:.3f}: J={d['score']:.3f} a={d['alpha']:.1f} Cl={d['CL']:.2f} LD={d['CL_CD']:.1f} Cp={d['Cpmin']:.2f}")
    print(af,' | '.join(s))
