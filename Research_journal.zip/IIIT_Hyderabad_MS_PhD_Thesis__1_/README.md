# Thesis — *Flying While Spinning* (v0)

MS by Research thesis, IIIT Hyderabad. Author: Aniketh Parkala. Advisor: Dr. Harikumar Kandath.

This folder holds **LaTeX and figures only**. Code, raw logs, CFD cases, CAD and videos stay in the research workspace (`01_literature/` … `08_media/`). Every figure records where it came from (see [Figure provenance](#figure-provenance)).

## Versions

| Version | What | Where it comes from |
|---|---|---|
| **v0** | ICUAS 2026 passive-lift platform; early control and fault-tolerance studies; MATLAB, MuJoCo/BEMT, PX4 SITL and Fluent CFD; 2025–26 flight campaigns | this workspace (`spin_drone/`) |
| **v1** | current work: lag-compensating control (eigen law, seat, pole adapter, actuator lead) in PX4, Isaac Sim/Pegasus + PX4 simulation ladder, EKF2 fixes, 2026 hardware flights | `PegasusSimulator/` (this thesis folder lives inside it) |

The thesis is organised by **topic chapters**. Each chapter holds versioned content side by side:

```
chapters/04_control/
├── control.tex        chapter wrapper: \chapter, overview, then \versioninput v0 / v1
├── overview.tex       short framing that holds across versions
├── v0/main.tex        sets \figdir, \inputs the v0 section files
├── v0/*.tex
├── v0/figures/
└── v1/                (follow-up work; does not exist yet)
```

### Adding v1 (follow-up work)
1. For every chapter the follow-up touches, create `chapters/NN_topic/v1/main.tex`. Its first line is `\renewcommand{\figdir}{chapters/NN_topic/v1/figures}`, followed by `\input` lines for its sections. Chapters without a `v1/main.tex` are skipped silently.
2. Add `appendices/v1/main.tex` if needed.
3. Create `bib/v1.bib`.
4. Set `\vonetrue` in `config/versions.tex`.
5. Update `overview.tex` in each touched chapter so it says how v0 and v1 relate (for example, "the initial approach" vs "the refined approach").
6. New shared notation goes into `config/macros.tex` and `glossary/symbols.tex`. Do not redefine existing macros in chapter files.

Do not edit v0 files to make room for v1. If v1 supersedes a v0 result, say so in v1 and in `overview.tex`.

## Conventions

| What | Rule |
|---|---|
| Labels | `<type>:<chap>-<ver>:<name>`, e.g. `fig:sim-v0:torque-balance`, `eq:model-v0:rotor-thrust`. Types: `fig tab eq sec subsec alg thm lem def prop rem cor asm ex`. Chapter keys: `intro bg model ctrl aero plat sim exp conc app`. Chapter labels are `ch:<key>`. |
| Figures | `\includegraphics{\figdir/name}`. File names: lowercase `snake_case`, only `[a-z0-9_-]`, one dot (the extension), no spaces. Prefer PDF over PNG. Keep each file under 5 MB. |
| Provenance | Every data figure carries `\figsource{<workspace path of the source file>}{<script / run that produced it>}` inside its `figure` environment. The command prints nothing; the static checker warns when it is missing. |
| Missing figures | `\placeholderfig{what it should show + data path}` plus `\todofig{...}`. |
| Notation | Use the macros in `config/macros.tex` for every listed quantity: `\angvel`, `\wx`/`\wy`/`\wz` (body rates, formerly p, q, r), `\spin` (spin rate ω_z), `\rotspeed{i}` (rotor speed Ω_i, formerly ω_i), `\cant` (cant angle α), `\aoa` (wing angle of attack; never α), `\inertia` (J; the paper used I), `\Rot`, `\kf`, `\ktau`, `\Rey`, `\CL`, `\Cl`, … |
| Draft notes | `\todoverify{}` (check a number or derivation), `\todoconflict{}` (sources disagree), `\todofig{}`, `\todocite{}`, `\todowrite{}`. Never put them inside captions, section titles or math. All of them disappear with `\showtodosfalse`. |
| Citations | A key lives in exactly one of `bib/core.bib` (related work shared by all versions), `bib/v0.bib` or `bib/v1.bib`. Never invent a DOI. |
| Numbers | Every number in the prose must trace to a source file. When sources disagree, use the final paper (`07_paper/ICUAS/main.tex`) and add `\todoconflict{}` naming both sources. |

## Build

```
latexmk        # build main.pdf (settings in .latexmkrc)
latexmk -c     # remove build files, keep the PDF
latexmk -C     # remove everything generated, including main.pdf and main.bbl
```

The `.latexmkrc` runs pdfLaTeX in nonstop mode with `file:line:` error messages and reruns BibTeX when a `.bib` file changes. Glossaries are built by `glossaries-extra` itself (the `automake` option), so no separate `makeglossaries` step is needed. If a build stops with a stale bibliography error, run `latexmk -C` and build again.

Two things break the build and are easy to reintroduce: a blank line inside `equation`, `align` or `\[ ... \]` (TeX reads it as a paragraph break), and a raw `&` in a `.bib` field (write `\&`).

On Ubuntu, install the packages with `sudo apt install texlive-latex-extra texlive-science texlive-publishers texlive-fonts-recommended latexmk` (or install `texlive-full`). Together these provide todonotes, glossaries-extra, siunitx, algorithmicx, IEEEtran.bst and IEEEabrv.bib, and Times. On Overleaf: upload this folder, set the main document to `main.tex`, and use the default compiler (pdfLaTeX). For a fast build of a single chapter, uncomment `\includeonly{...}` in `main.tex`.

For the submission build, set `\showtodosfalse` in `config/versions.tex`.

## Layout

```
main.tex                 thin driver
config/                  versions.tex (toggles), macros.tex (notation), preamble.tex (packages), meta.tex (title/author/date)
frontmatter/             title page, copyright, certificate, acknowledgements, abstract, related publications
glossary/                acronyms.tex, symbols.tex
bib/                     core.bib, v0.bib  (+ v1.bib later)
chapters/01_introduction … 09_conclusion
appendices/v0/
figures/common/          institute logo
tools/                   check_thesis.py, extract_provenance.py, v0_scripts/ (drafting-time analysis scripts)
PROVENANCE_AND_ISSUES.md generated: figure sources + all open draft notes
_template_samples/       original IIIT template sample content (not compiled; safe to delete)
```

## Tools

| Tool | Purpose |
|---|---|
| `python tools/check_thesis.py [--only <path-substring>]` | Static check, needed because no TeX is installed on the author's machine. It fails on missing inputs or graphics, undefined or duplicate labels, unknown cite or glossary keys, unbalanced braces or environments, and spaces in file names. It warns about label-scheme violations and figures without `\figsource`. |
| `python tools/check_case.py` | Checks that every referenced path matches the case of the file on disk. Windows is case-insensitive and Linux builds are not, so run it after adding figures on Windows. |
| `python tools/extract_provenance.py PROVENANCE_AND_ISSUES.md` | Regenerates the figure-provenance table and the open-issues list from the .tex files. |
| `tools/v0_scripts/` | Scripts written during the v0 drafting that produced figures or numbers appearing in the thesis. They are grouped by chapter, and they read the workspace data in place using absolute paths. |

Run the tools with the workspace venv: `..\.venv\Scripts\python.exe tools\check_thesis.py`.

## Status of v1 (2026-10-03)

- **Enabled:** `\vonetrue` in `config/versions.tex`. v1 sits after v0 in chapters 1--4 and 6--9 (chapter 5, aerodynamics, has no v1) and adds three appendices (lag lemmas, v1 PX4 parameters, reproducibility).
- **Size:** about 79,000 words of v1 prose, about the same as v0; the full thesis builds to 476 pages.
- **Checker and build:** 0 errors; `latexmk` builds with no LaTeX errors and no undefined references. The checker and `extract_provenance.py` now read the enabled versions from `config/versions.tex` and tag figures and issues by version.
- **Notation:** v1 symbols are in `config/macros.tex` and `glossary/symbols.tex` under the "v1" block (`\seatang`, `\seaterr`, `\Tact`, `\tauact`, `\Gact`, `\Mdyn`, ...). v1's skew matrix `\Sj` has the opposite sign to v0 Sec. 4.6; this is stated where it is introduced.
- **Positioning:** the contribution claimed is the seat's observable (unit derivative, model-free), not the rotation; the eigen law is the baseline. See `subsec:ctrl-v1:seat-novelty` and `subsec:ctrl-v1:eigen-position`.
- **Open:** 7 v1 placeholder figures; all draft notes are listed by version in [PROVENANCE_AND_ISSUES.md](PROVENANCE_AND_ISSUES.md).
- **Statements at risk pending re-analysis of the archived b data:** "the lag closes the window b lives in", "b = 0 is the predicted outcome" (eigen_law.tex), "the archived sweep does not support b*" (pole_adapter.tex), and the b-vs-lag table reading, GA generation count and July-archive exclusion reason in results_level1.tex. The archived b-vs-lag sweep only tested b >= 0. A planned signed-b sweep and seat-off b ladder would settle them.

## Status of v0 (2026-10-03)

- **Size:** all nine chapters and five appendices are drafted, about 78,000 words.
- **Checker:** 94 .tex files, 546 labels, 57 cited keys, 71 graphics; 0 errors and 0 warnings.
- **Build status (2026-10-03):** compiles locally with TeX Live 2022 to a 474-page PDF with no errors, undefined references or undefined citations. About 160 overfull boxes remain.
- **Provenance and open issues:** every data figure records its source, and every disputed number carries a `\todoconflict` or `\todoverify` note. See [PROVENANCE_AND_ISSUES.md](PROVENANCE_AND_ISSUES.md) for the full lists: 22 conflicts, 123 verify notes and 8 figures still to be generated.

## Open issues to resolve before submission (curated)

**Consistency across chapters**
1. *Frame convention.* Chapter 3 uses NED (z down), while Sections 4.4 (Lyapunov) and 4.5 (embedding) use z-up; both state their convention in the text. The ICUAS paper's equations are z-up. Pick one convention.
2. *Symbol clashes.* Several chapter-local symbols collide with macros or with each other:
   - η = φ + jθ (complex tilt, Chapter 3) clashes with `\eul`;
   - μ (complex moment) clashes with `\muair`;
   - κ = k_τ/k_f (Chapter 3) clashes with κ_V (Chapter 4);
   - ϖ in Chapter 4 equals −k in Chapter 3.
   
   About 40 chapter-local symbols are written raw; promote the shared ones to `config/macros.tex`.
3. *Theorem environments.* The lemmas and theorems in Section 4.4 and Appendix B are bold run-in text. Consider adding `amsthm`.
4. *Rotor numbering.* Chapter 3 uses an × layout numbered 1 rear-left, 2 front-left, 3 rear-right, 4 front-right. It still has to be mapped to the PX4 motor indices.

**Data and claims that need the author's input**
5. *Halved attitude figure.* In `config1_config_2_hist.png` the Configuration II roll and pitch are scaled by 0.5 (`plot_attitude.py:92`). The caption discloses this; the reason is still to be stated. An unscaled version can be produced with `tools/v0_scripts/experiments/plot_attitude_unhalved.py`.
6. *Inconsistencies in the published paper.* These are kept as `\todoconflict` notes:
   - steady-state error 0.008 m vs 0.027 m; settling time ~2 s vs ~3 s;
   - induced velocity taken from total vs vertical thrust, which affects the 37.6 W and 57.1 % figures;
   - spin limit 8–10 vs 8–12 rad/s;
   - yaw-torque split 98.5/1.5 % vs 96.3/3.7 % from the simulation's own parameters;
   - CFD lift 3.35 N → 4.50 N, and a non-zero in-plane force of 4.23 N;
   - N = 5 trials claimed vs the files actually present;
   - thrust-map bench point 450 g vs about 567 g from the bench table;
   - the wording of the 22 % headline.
7. *Hardware unknowns.* The ESC model; Kakute H7 Mini vs the full-size H7 board; the as-built wing pitch. k_f, k_τ, J_r and the inertias were never measured; κ = 0.015 m is taken from the simulation script.
8. *Code findings.*
   - The MuJoCo control scripts (`eigen_Sim.py`, `eigen_so3.py`, `LQR.py`) assume J = diag(0.01, 0.01, 0.02), but `quad.xml` has 2/2/4.
   - The archived offboard node computes the yaw prediction but does not apply it.
   - `backstepping_controller.py` breaks its own cancellation.

**New analysis introduced while drafting.** None of this is in the original notes; review it.
9. With the rotor-torque square restored, the allocation matrix of Configuration II has rank 3: M_ψ = G·F_z, so yaw is slaved to thrust. Configuration I retains weak independent yaw authority.
10. The drafts' open-loop roll–pitch analysis was re-derived. The polynomial becomes (s²+k²)(s²+ω̄²) and the step-response mean is corrected. Under PD the precession decay scales as ϖ⁻². A closed-form wing-lift fraction λ = G/(G+ρ_D) gives 0.67, against 0.672 from the simulation.
11. Corrections to the theory notes:
    - The proofs from the January 2026 notes were repaired (Section 4.4, Appendix B).
    - The eigenvalue-shift result of `att_control_theory.pdf` was corrected.
    - The March 2026 notes were corrected.
    - The "retain the skew coupling" law (`eq:ctrl-v0:emb-retain`) is a new implication.
12. Fault tolerance: the revolution-averaged authority after one rotor failure is exactly ¾ of nominal. The RMS value including the 2ω_z ripple is √10/4 ≈ 0.79, which corrects the RMS claim in the ICRA draft.
13. Actuation lag rotates the commanded moment by χ = ω_z·τ_d, about 14–20°. This is recorded as a v0 observation and motivates the v1 control work.

**Still to produce:** 7 placeholder figures:
- MIMO margins
- eigenvalue sweep
- embedding sweep
- INDI architecture
- avionics block diagram
- 2025 campaign time histories
- motor-kill histories

The proof-of-concept Excel charts also need re-plotting. Several 2023–26 related-work papers are described from their titles only, because no PDF is in the workspace.
