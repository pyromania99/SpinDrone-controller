# Build with:  latexmk          (clean: latexmk -c, full clean: latexmk -C)
@default_files = ('main.tex');
$pdf_mode = 1;                       # pdflatex, as on Overleaf
set_tex_cmds('-interaction=nonstopmode -file-line-error -synctex=1 %O %S');
$bibtex_use = 2;                     # rerun BibTeX when .bib changes; -C also removes main.bbl
# glossaries-extra[automake] runs makeindex itself; let latexmk clean its files.
push @generated_exts, qw(glo gls glg slo sls slg ist tdo lof lot out);
$clean_full_ext = 'synctex.gz';
